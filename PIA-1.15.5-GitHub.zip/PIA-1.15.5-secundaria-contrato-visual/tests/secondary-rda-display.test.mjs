import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const read=f=>readFile(new URL('../'+f,import.meta.url),'utf8');
async function fixture(level,modules,cycle='III Ciclo'){
 const ctx=vm.createContext({console});
 for(const f of ['src/data/pnft-data.js','src/data/rda-por-ciclo.js','src/data/preschool-curriculum.js','src/data/curricular-framework.js','src/domain/projection/projection-core.js'])vm.runInContext(await read(f),ctx);
 const runtime=await read('src/application/enhancements.js'),helper=runtime.slice(runtime.indexOf('function curricularAreasForDisplay()'),runtime.indexOf('function currentConcepts()')),rda=runtime.slice(runtime.indexOf('function renderProjectionRdas()'),runtime.indexOf('function renderProjectionOptions('));
 vm.runInContext(`globalThis.level=${JSON.stringify(level)};globalThis.modules=${JSON.stringify(modules)};globalThis.cycle=${JSON.stringify(cycle)};globalThis.selectedAreas=[];globalThis.state={projection:{preschoolTrack:'optimal',conceptIds:[]}};globalThis.elements={piaProjectionRdas:{innerHTML:''},piaCurricularFramework:{innerHTML:''}};function $(id){return id==='nivel'?{value:level}:id==='ciclo'?{value:cycle}:elements[id];}function checked(name){return name==='piaModule'?modules:name==='piaArea'?selectedAreas:[];}function curriculumData(){return PNFT_DATA;}function secondaryEnabled(){return cycle==='III Ciclo'&&['7°','8°','9°'].includes(level);}function selectedConcepts(){return [];}function curriculumRda(area){return RDA_POR_CICLO[cycle]?.[area]||'';}`,ctx);
 vm.runInContext(helper+rda,ctx);return ctx;
}
for(const level of ['7°','8°','9°'])for(const module of ['Módulo 1','Módulo 2'])test(level+' '+module+': referentes visibles sin incluir saberes',async()=>{
 const ctx=await fixture(level,[module]);
 const before=vm.runInContext('JSON.stringify({state,selectedAreas,modules})',ctx);
 vm.runInContext('renderProjectionRdas()',ctx);
 const expected=vm.runInContext('Object.keys(PNFT_DATA[level][modules[0]])',ctx);
 for(const area of expected){
  assert.ok(ctx.elements.piaProjectionRdas.innerHTML.includes(area));
  assert.ok(ctx.elements.piaProjectionRdas.innerHTML.includes(vm.runInContext('curriculumRda('+JSON.stringify(area)+')',ctx)));
  assert.ok(ctx.elements.piaCurricularFramework.innerHTML.includes(area));
 }
 assert.match(ctx.elements.piaCurricularFramework.innerHTML,/Competencias específicas/);
 assert.match(ctx.elements.piaCurricularFramework.innerHTML,/Perfil de salida del ciclo/);
 assert.equal(vm.runInContext('JSON.stringify({state,selectedAreas,modules})',ctx),before);
 assert.equal(vm.runInContext('currentCurricularFramework().competencies.length',ctx),0,'Consultar no amplía el marco usado por prompts y ruta');
});
test('sin módulo: mensaje explícito; cambio de módulo elimina referentes anteriores',async()=>{
 const ctx=await fixture('8°',[]);
 vm.runInContext('renderProjectionRdas()',ctx);assert.match(ctx.elements.piaProjectionRdas.innerHTML,/Seleccione un módulo/);
 vm.runInContext("modules=['Módulo 1'];renderProjectionRdas()",ctx);
 vm.runInContext("modules=['Módulo 2'];renderProjectionRdas()",ctx);
 const areas=vm.runInContext('curricularAreasForDisplay()',ctx);
 assert.equal((ctx.elements.piaProjectionRdas.innerHTML.match(/class="pia-rda-card"/g)||[]).length,areas.length);
});
test('otros ciclos conservan consulta por áreas seleccionadas',async()=>{
 const ctx=await fixture('4°',['Módulo 1'],'II Ciclo');
 vm.runInContext('renderProjectionRdas()',ctx);assert.match(ctx.elements.piaProjectionRdas.innerHTML,/Recuerde seleccionar/);
 vm.runInContext("selectedAreas=[Object.keys(PNFT_DATA[level][modules[0]])[0]];renderProjectionRdas()",ctx);
 assert.equal((ctx.elements.piaProjectionRdas.innerHTML.match(/class="pia-rda-card"/g)||[]).length,1);
});
