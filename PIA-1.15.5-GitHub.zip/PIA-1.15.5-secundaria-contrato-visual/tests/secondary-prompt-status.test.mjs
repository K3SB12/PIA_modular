import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const read=p=>readFile(new URL('../'+p,import.meta.url),'utf8');
const ctx=vm.createContext({});
for(const file of ['src/data/project-component-catalog.js','src/data/evaluation-profiles.js','src/domain/projection/projection-core.js','src/prompts/semester-projection-prompt.js'])vm.runInContext(await read(file),ctx);
vm.runInContext('globalThis.qa={secondary:PIASecondaryPlanningCore,prompt:PIASemesterPrompt}',ctx);
const {secondary,prompt}=ctx.qa;
test('guardar un borrador no confirma semanas o ubicaciones pendientes; el contexto puede quedar abierto',()=>{
 const c=[{id:'a',name:'Saber'}];
 assert.equal(secondary.distributionStatus(c,{},14).complete,false);
 assert.equal(secondary.distributionStatus(c,{a:{weeks:[2,6,10]}},14).complete,false);
 const assignment={a:{weeks:[2,6,10],phaseIds:['prototype','test-evaluate']}};
 assert.equal(secondary.distributionStatus(c,assignment,14).complete,true);
 assert.equal(secondary.distributionStatus(c,assignment,14,{6:{lessons:0}}).complete,false);
 assert.equal(secondary.distributionStatus(c,assignment,9).complete,false);
 assert.equal(secondary.distributionStatus([],{},14).complete,false);
});
test('secundaria conserva decisiones y requisitos de etapas sin imponer tiempo ni producto',()=>{
 const text=prompt.build({level:'8°',cycle:'III Ciclo',weeks:14,lessons:28,blockMinutes:80,methodology:'APD',procedural:[],attitudinal:[],curricularRouteBlock:'Estado: Borrador\nSemanas exactas: 2, 6, 10\nIndicador oficial: Identificar mecanismos.',projectPlanning:{enabled:true},evaluationProfile:{components:[['Proyecto',40]]}});
 for(const phrase of ['REGLAS EXCLUSIVAS DE SECUNDARIA','Semanas exactas: 2, 6, 10','Identificar mecanismos.','no la incorpore sin decisión docente','Etapa III Final','ni exija un cuarto instrumento','No imponga una división','PIA conserva las decisiones docentes'])assert.ok(text.toLowerCase().includes(phrase.toLowerCase()),phrase);
 assert.ok(!text.includes('mixta (40 min currículo + 40 min Proyecto)'));
});
test('los prompts de preescolar, I y II Ciclo permanecen exactamente iguales a la base 1.15.5',async()=>{
 const fixtures=JSON.parse(await read('tests/fixtures/prompt-other-cycles-v1.15.5.json'));
 for(const {input,sha256} of fixtures)assert.equal(createHash('sha256').update(prompt.build(input)).digest('hex'),sha256,`${input.level} ${input.modules[0]}`);
});
