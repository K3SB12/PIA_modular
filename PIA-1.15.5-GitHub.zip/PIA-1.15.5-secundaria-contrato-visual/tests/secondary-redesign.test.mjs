import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const read=f=>readFile(new URL('../'+f,import.meta.url),'utf8'),context=vm.createContext({});
for(const f of ['src/data/pnft-data.js','src/data/rda-por-ciclo.js','src/data/project-component-catalog.js','src/domain/projection/projection-core.js'])vm.runInContext(await read(f),context);
vm.runInContext('globalThis.qa={data:PNFT_DATA,core:PIAProjectionCore,secondary:PIASecondaryPlanningCore,rda:RDA_POR_CICLO}',context);const {data,core,secondary,rda}=context.qa;
const plain=v=>JSON.parse(JSON.stringify(v));
function proposal(concepts){return {schema:'pia-secondary-organization-v1',fingerprint:'vigente',options:[{id:'A',title:'Práctica e integración',reason:'Ejemplo de validación estructural',assignments:concepts.map(c=>({conceptId:c.id,included:true,weeks:[2,6,10],phaseIds:['prototype','test-evaluate'],secondary:{lessons:true},evaluationComponent:'Trabajo cotidiano'})),calendar:[{week:3,phaseIds:['empathize','define','ideate'],activity:'Situación por construir'}]}]};}
for(const [level,module] of [['7°','Módulo 1'],['7°','Módulo 2'],['8°','Módulo 1'],['8°','Módulo 2'],['9°','Módulo 1'],['9°','Módulo 2']])test(`ayuda previa ${level} ${module}: inventario completo, propuesta sin problema ni producto impuestos`,()=>{
 const concepts=core.listConcepts(data,level,[module],Object.keys(data[level][module]));const raw=proposal(concepts),parsed=secondary.validateOrganization(raw,concepts,14,{5:{lessons:0}},'vigente',true);
 assert.equal(parsed[0].assignments.length,concepts.length);assert.deepEqual(plain(parsed[0].assignments[0].weeks),[2,6,10]);assert.ok(!('problem' in parsed[0]));assert.ok(!('expectedSolution' in parsed[0]));
 const defaultState=core.defaultEnhancements();defaultState.secondaryPlanning={...defaultState.secondaryPlanning,tab:'project',projectPhase:'test-evaluate',organizationResponse:JSON.stringify(raw),organizationOptions:parsed,projectStageNotes:{'test-evaluate':{tests:'Prueba prevista',dua:'Representación múltiple',provisionalAchievement:'Acuerdo asesor',provisionalSource:'No oficial'}}};const migrated=core.migrate(JSON.parse(JSON.stringify({pia:defaultState})));assert.deepEqual(plain(migrated.secondaryPlanning),plain(defaultState.secondaryPlanning));
});
test('las propuestas inválidas no pueden aplicarse ni alterar el calendario o el currículo',()=>{
 const concepts=[{id:'c',name:'Saber',indicators:['Identificar un mecanismo.']}],raw=proposal(concepts),check=v=>secondary.validateOrganization(v,concepts,14,{5:{lessons:0}},'vigente',true);
 const invalid=[{...raw,fingerprint:'vieja'},{...raw,options:[{...raw.options[0],assignments:[]}]},{...raw,options:[{...raw.options[0],assignments:[{...raw.options[0].assignments[0],conceptId:'otro'}]}]},{...raw,options:[{...raw.options[0],assignments:[{...raw.options[0].assignments[0],weeks:[5]}]}]},{...raw,options:[{...raw.options[0],assignments:[{...raw.options[0].assignments[0],officialIndicators:['Programar todo.']}]}]},{...raw,options:[{...raw.options[0],calendar:[]}]}];
 for(const value of invalid)assert.throws(()=>check(value));assert.throws(()=>secondary.validateOrganization(raw,concepts,14,{},'vigente',false));assert.deepEqual(raw,proposal(concepts));
});
test('los RdA secundarios y los descriptores coinciden con los referentes aportados',()=>{
 assert.equal(rda['III Ciclo']['Apropiación tecnológica y Digital'],'Combina herramientas digitales, tomando en cuenta fundamentos de tecnología, impacto de las TIC, seguridad y privacidad digital y, su experiencia de uso, en la realización de productos digitales.');
 assert.match(rda['III Ciclo']['Programación y Algoritmos'],/^Integra conceptos de programación como eventos,/);assert.match(rda['III Ciclo']['Computación física y Robótica'],/^Aplica fundamentos de robótica,/);assert.match(rda['III Ciclo']['Ciencia de datos e Inteligencia artificial'],/^Analiza datos mediante herramientas digitales/);
 assert.equal(secondary.descriptors.depura,'Valida el funcionamiento de los algoritmos en busca de errores para corregirlos al resolver un problema o situación.');assert.equal(Object.keys(secondary.descriptors).length,17);
});
test('el rediseño no cambia los RdA anteriores a III Ciclo',async()=>{
 const source=await read('src/data/rda-por-ciclo.js');const fixture=JSON.parse(await read('tests/fixtures/rda-other-cycles.json'));assert.equal(createHash('sha256').update(source.slice(0,source.indexOf('"III Ciclo":'))).digest('hex'),fixture.sha256);
});
