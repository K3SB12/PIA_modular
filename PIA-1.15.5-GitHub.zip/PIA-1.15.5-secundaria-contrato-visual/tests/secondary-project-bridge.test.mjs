import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
test('trasladar Proyecto conserva identidad, valores y regreso al contenedor original',async()=>{
 const source=await readFile(new URL('../src/application/enhancements.js',import.meta.url),'utf8');
 const start=source.indexOf('const secondaryProjectFieldIds='),end=source.indexOf('// PIA_SECONDARY_PROJECT_BRIDGE_1154_END',start);
 const nodes=new Map(),homes=new Map(),ids=['piaProjectName','piaProjectBeneficiary','piaProjectProblem','piaProjectSolution','piaProjectIndicators'];
 const original={};
 for(const id of ids){
  const node={id,location:'original',remove(){this.location='detached';},before(home){homes.set(home.id,home);home.original=this;home.after=n=>n.location='original';}};
  const input={id,value:'Texto histórico '+id,closest:()=>node};nodes.set(id,id==='piaProjectIndicators'?node:input);original[id]=id==='piaProjectIndicators'?node:input;
 }
 const ctx=vm.createContext({document:{createElement:()=>({})},$:id=>nodes.get(id)||homes.get(id),state:{evaluation:{confirmed:true,profileId:'secondary'}},profileHasProject:()=>true,PIAEvaluationProfiles:{get:()=>({})}});
 vm.runInContext(source.slice(start,end)+';globalThis.bridge={detach:secondaryDetachProjectFields,attach:secondaryAttachProjectFields};',ctx);
 const host={querySelector:slot=>({append(node){node.location=slot;}}),querySelectorAll:()=>[]};
 for(let i=0;i<3;i++){const fields=ctx.bridge.detach(true);assert.equal(fields.length,5);ctx.bridge.attach(fields,host);for(const id of ids){assert.equal(nodes.get(id),original[id]);if(id!=='piaProjectIndicators')assert.equal(nodes.get(id).value,'Texto histórico '+id);}}
 assert.equal(homes.size,5,'No duplica marcadores al volver a renderizar');
 ctx.bridge.detach(false);for(const id of ids)assert.equal((id==='piaProjectIndicators'?nodes.get(id):nodes.get(id).closest()).location,'original');
});
test('la depuración mantiene habilitación por perfil y organizador independiente',async()=>{
 const source=await readFile(new URL('../src/application/enhancements.js',import.meta.url),'utf8');
 assert.match(source,/wrap.hidden=!compatible\|\|secondaryEnabled\(\)/);
 assert.match(source,/secondaryDetachProjectFields\(enabled\)/);
 assert.match(source,/secondaryAttachProjectFields\(projectFields,host\)/);
 assert.match(source,/state.evaluation.confirmed&&profileHasProject/);
 const html=await readFile(new URL('../src/templates/enhancements.html',import.meta.url),'utf8');
 assert.match(html,/id="piaCurricularRoutePlannerWrap"/);
 assert.match(html,/id="piaEvaluationProfileConfirmed"/);
});
