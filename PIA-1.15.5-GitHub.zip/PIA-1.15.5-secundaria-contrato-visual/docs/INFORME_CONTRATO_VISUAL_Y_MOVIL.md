# Contrato visual, ensayo docente y responsividad

Entrega derivada de PIA 1.15.5. Los informes de otras entregas son antecedentes, no evidencia de esta revisión.

## Verificación ejecutada

- 316/316 pruebas automatizadas de código; verificación de fuente, cambios autorizados y huellas de salida aprobada.
- 20/20 escenarios de regresión en navegador.
- 18/18 escenarios de pestañas y compatibilidad.
- 22/22 escenarios del contrato visual y recorrido docente; sin errores JavaScript.
- 16 combinaciones de ciclo y ancho móvil: preescolar, I ciclo, II ciclo y III ciclo a 320, 360, 390 y 430 px. Anchura del documento igual a la pantalla; ningún control visible detectado fuera de ella.
- Secundaria: pestañas y editor comprobados a esos cuatro anchos; orientación horizontal 844 × 390. La distribución mantiene desplazamiento contenido cuando una tabla lo requiere.

## Cambios de alcance

Secundaria: selectores del encabezado conectados con los controles originales; ayuda contextual; agrupación visual de semanas; editor de rangos con confirmación; selección del instrumento previsto; revisión y salidas sobre la misma distribución.

La corrección móvil general fue autorizada expresamente después de detectar desbordamientos. Solo cambia presentación mediante CSS de pantalla pequeña: datos administrativos apilados, encabezados flexibles, botones en varias filas, navegación de semanas, columnas semanales y cuadros de descriptores. No cambia textos, datos curriculares, cálculo de notas, guardado, exportadores ni el orden de las secciones de otros ciclos.

## Evidencia y límites

Los seis JSON de `docs/contratos-visuales-secundaria` reconstruyen lo visible y los comportamientos acordados; no extraen código oculto de imágenes. Incluyen referencias y excepciones explícitas para proteger contenidos oficiales y decisiones docentes. Capturas de la aplicación real en `tests/teacher-evidence`.

El ensayo detallado es octavo, módulo 1: proyección de 17 semanas y planeamiento de una semana de desarrollo del Proyecto. Los seis casos de nivel/módulo comprueban referentes e inventario, no seis planeamientos completos. Situación y producto permanecen abiertos. La factibilidad pedagógica final requiere revisión docente.

Ensayo interno con Chromium, no prueba con docentes participantes ni certificación del MEP. No se probaron Safari/iOS, dispositivos físicos o lectores de pantalla. Se verificaron JSON, recuperación, portable, contenido Word existente (.doc), ventanas de impresión y generación PDF. No se ensayó Microsoft Word o impresión física.

Resultados reproducibles: `tests/secondary-browser-results.json`, `tests/secondary-tabs-browser-results.json`, `tests/secondary-teacher-visual-results.json`. Scripts de navegador requieren Playwright y una ruta Chromium configurados según su encabezado; no se añaden servicios externos ni envío automático a IA.
