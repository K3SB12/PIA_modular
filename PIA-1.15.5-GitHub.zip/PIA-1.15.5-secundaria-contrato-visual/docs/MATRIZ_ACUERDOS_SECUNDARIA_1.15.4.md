# Matriz de acuerdos — secundaria PIA 1.15.4

Esta matriz recoge los acuerdos visibles de esta conversación. Implementado significa presente en código; no equivale a validado en navegador ni a aprobado pedagógicamente.

| Acuerdo | Ubicación / implementación | Comprobación y pendiente |
|---|---|---|
| Exclusivo de sétimo a noveno, módulos 1 y 2 | secondaryEnabled; inventario de currículo oficial | Seis combinaciones probadas en Node; navegador final pendiente |
| Áreas correspondientes visibles | Barra de áreas; filtro independiente de inclusión | Catálogo conservado; presentación compactada sin captura final |
| Docente selecciona, PIA orienta | Inclusión explícita; guía reversible de seis pasos | No distribución automática al Proyecto; usabilidad pendiente |
| Indicadores oficiales protegidos | Catálogos e inspector literal | Fuente y pruebas de catálogo; sin edición curricular |
| Movilidad independiente de semanas | Subir/bajar y campo de posición | Pruebas de movimiento y conservación |
| Integración misma área / áreas distintas | Vínculos entre saberes y aporte opcional | Conserva identidad e indicadores; pertinencia docente |
| Semanas editables y no consecutivas | Escritura y selector; calendario por semana | Rangos y semanas separadas probados |
| Recesos y disponibilidad parcial | Lecciones 0/1/2; asignaciones conservadas | Sin inferir feriados; calendario probado |
| Etapas completas de Proyecto y lecciones pedagógicas | Ubicación por saber y calendario | Varias fases previstas; no fija secuencia de ejemplo |
| Etapa I Inicial con indicadores propios | Selector trasladado al nuevo módulo | Habilitación por perfil; traslado probado en modelo DOM |
| Etapa II Desarrollo y Etapa III Final desde saberes | Inspector y evaluación prevista por etapa | Sin repartir todos los indicadores automáticamente |
| Situación y prototipo pendientes | Contexto plegable con campos originales | No obligatorios; prueba funcional de campos movidos pendiente |
| Producto según propósito y acción del indicador | Orientación del contexto y fundamento | No imponer producto programado ni comunicativo; revisión docente |
| Mediación como andamiaje | Pestaña Mediación y recordatorios | Metodología conservada; desarrollo docente contextual |
| Procedimentales, actitudinales y ejes | Pestaña Mediación | Persistencia de asignaciones probada; no currículo inventado |
| Progresión, integración, profundidad, competencias, perfiles y RdA | Trayectoria y marco curricular existentes; recordatorios | Apoyos presentes; no certifican logro. Alerta detallada de continuidad requiere revisión pedagógica |
| Evaluación prevista sin situación definida | Registro provisional por etapa | Contextualizar después de Idear y antes de valorar |
| Instrumentos, evidencia, criterios, descriptores y puntos | Registro de evaluación por etapa | Elaboración/comunicación previas; no notas estudiantiles |
| Porcentaje final y no doble valoración | Perfil MEP y recordatorios | Catálogo sin modificación; sin calculadora de notas por etapa |
| Trabajo cotidiano y tareas | Oportunidad evaluativa, perfil y planeamiento | No se eliminan por integrar Proyecto |
| Organizar la ruta curricular opcional | Organizador vigente con mismo estado | No se retira; no obliga a repetir la proyección |
| Retirar Componente Proyecto viejo | Pantalla oculta solo en secundaria; campos trasladados | No borra registros ni elimina evaluación semanal |
| Guardado, JSON, autoguardado y portable | Contratos originales con mismos controles | Suite de persistencia previa; recorrido real tras traslado pendiente |
| Impresión separada y Word/PDF oficial | Exportadores existentes | Proyección separada; nueva impresión final en navegador pendiente |
| Diseño aprobado y accesibilidad móvil | Panel, regreso, guía compacta y lista desplazable | Fidelidad visual completa NO comprobada; falta revisión real |
| Modo docente | Revisión anterior de alcance | No equivale a pilotaje con docente nuevo; aprobación pendiente |

Las capturas del diseño anterior no constituyen evidencia visual de esta entrega. No debe declararse “todo cumplido al 100 %” mientras persistan estas comprobaciones.
