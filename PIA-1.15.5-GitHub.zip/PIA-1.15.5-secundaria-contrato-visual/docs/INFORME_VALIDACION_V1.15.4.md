# Validación PIA 1.15.4 — entrega para revisión

## Cambio autorizado

Retirar la pantalla anterior Componente Proyecto solo en secundaria e integrar sus funciones necesarias. Los controles originales de nombre, beneficiarios, situación y solución se trasladan al nuevo contexto plegable, conservando identidad, valores y eventos. El selector original de indicadores propios de Etapa I Inicial se traslada a su apartado. El perfil confirmado sigue habilitando Proyecto.

La Etapa II Desarrollo y la Etapa III Final se deciden desde los saberes. Se mantiene Organizar la ruta curricular, el catálogo MEP, los registros semanales y la compatibilidad de JSON v6. No se cambia currículo oficial ni el catálogo de porcentajes.

## Pruebas

Resultado de esta entrega: npm test aprobado; 292/292 pruebas Node, cero fallos; controles de fuente, build, alcance autorizado e integridad aprobados.

La suite incluye las 290 pruebas previas y dos pruebas nuevas: traslado repetido y retorno de controles sin perder identidad/valores ni duplicar marcadores; comprobación de habilitación por perfil y conservación del organizador. Los controles de fuente, build, alcance autorizado e integridad se ejecutan mediante npm test.

Estas pruebas no sustituyen interacción real en navegador. No se pudo ejecutar una nueva prueba de navegador en este entorno; las capturas y el registro secondary-browser-results.json corresponden a una ejecución anterior, no a 1.15.4. Falta verificar especialmente los campos trasladados, su autoguardado, recarga, JSON exportado, portable y retorno al cambiar de ciclo en navegador real. También falta comprobar legibilidad, desplazamiento y fidelidad visual en celular/tablet.

Esta entrega no se rotula como implementación completamente validada ni como aprobación docente. No certifica aprendizaje ni RdA. Consulte la matriz de acuerdos para separar implementación y comprobación pendiente.

## Integridad

SHA-256 de las tres salidas HTML idénticas: `df8d6a7b5388537f10e1cc91244c658466275936d196b6b94b5067f21ad03d13`.
