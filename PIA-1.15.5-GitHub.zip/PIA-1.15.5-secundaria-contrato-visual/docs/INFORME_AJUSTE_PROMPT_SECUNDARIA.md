> Informe histórico del ajuste anterior. El rediseño posterior está documentado en INFORME_REDISENIO_SECUNDARIA.md.

# Ajuste del prompt de secundaria — PIA 1.15.5

Fecha: 6 de octubre de 2026. Base: PIA-PNFT-Modular-v1.15.5.

## Cambio entregado

El botón de secundaria se denomina **Guardar y revisar distribución**. Guardar no convierte automáticamente una distribución incompleta en confirmada. PIA diferencia **Borrador**, **Distribución organizada; pendiente de revisión docente** y **Distribución revisada por la persona docente**. La revisión es estructural: no acredita pertinencia pedagógica, aprendizaje o logro del RdA. La situación problema y el producto pueden permanecer pendientes de construcción con el estudiantado.

Se corrigió el orden de actualización del estado al guardar: antes, calcular la huella normalizaba el objeto y podía dejar la fecha y huella en una copia que no se conservaba. Ahora se calculan antes de actualizar el estado vigente. Al cargar se revisan las banderas históricas. Los cambios en el marco temporal secundario también forman parte de la huella.

El prompt semestral conserva su estructura y contrato de respuesta A–H. Para secundaria desarrolla las decisiones guardadas, conserva semanas no consecutivas y pendientes, distingue las tres etapas del Proyecto, respeta indicadores oficiales y los indicadores de evaluación decididos por la persona docente, y solicita contextualización de las sugerencias. Mantiene abiertos situación y producto; incluye metodología, DUA, saberes procedimentales, saberes actitudinales, ejes transversales, progresión y contribución a competencias, perfiles y RdA. Se eliminó la imposición de dividir la semana en 40 + 40 minutos en las instrucciones secundarias.

Las propuestas de IA continúan siendo propuestas: estas reglas orientan la generación y no garantizan por sí solas que un modelo externo las cumpla. La revisión profesional continúa siendo necesaria.

## Validación

- **303 pruebas automatizadas aprobadas**, cero fallos; verificación de fuente, compilación, cambios autorizados e integridad aprobadas.
- **20 pruebas en Chromium aprobadas**, cero errores JavaScript registrados.
- Recorrido real de sétimo, octavo y noveno, módulos 1 y 2.
- Borrador incompleto y revisión de una distribución organizada.
- Autoguardado, recarga y recuperación del estado.
- Descarga JSON y carga mediante selector de archivo; comparación de calendario, asignaciones y prompt.
- Edición manual del prompt, guardado, descarga, carga y reapertura: texto conservado literalmente.
- Consulta de secundaria: semanas exactas, fases, evidencias y recesos conservados.
- Word: vista previa y descarga real .doc con el indicador y la mediación esperados.
- PDF: vista previa y generación real de bytes PDF válidos con el contenido semanal esperado.
- Portable: descarga real y apertura autónoma; edición y recuperación del estado embebido.
- Controles de secundaria en anchos de 390, 820 y 1440 píxeles.
- Comparación exacta de los prompts de preescolar y de primero a sexto, módulos 1 y 2: **14 casos idénticos a la base**.

Los catálogos curriculares y RdA no se modificaron en este ajuste. Los exportadores de Word/PDF conservan la separación entre proyección docente y planeamiento oficial. No se rediseñó la interfaz completa de pestañas en esta entrega: el alcance implementado es el prompt, los estados de revisión y su persistencia.

La verificación en Chromium no sustituye una prueba en Safari o en un dispositivo físico; Word se comprobó como archivo descargable, sin abrir Microsoft Word.

## Uso

1. Descomprima el ZIP y abra `index.html` en su navegador.
2. Cargue su JSON habitual si ya tiene un planeamiento.
3. En secundaria, revise la distribución y pulse **Guardar y revisar distribución**.
4. Genere el prompt semestral. Si existe un prompt editado, PIA lo conserva; para incorporar las nuevas instrucciones utilice el control de actualización y revise el texto antes de sustituirlo.

Las salidas raíz, web y portable son idénticas. SHA-256 del HTML: `090bc36a7be9b9b5cf20e929617955f067f63648c9d4d2d52cdf4f38ec1d3378`.

Las evidencias de pruebas están en `tests/secondary-browser-results.json`, `tests/secondary-export-validation.pdf` y `docs/VALIDACION_AJUSTE_PROMPT.log`.
