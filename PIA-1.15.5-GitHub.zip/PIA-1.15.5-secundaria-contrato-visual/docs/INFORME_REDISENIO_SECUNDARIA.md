# Rediseño de secundaria — PIA 1.15.5

Entrega: 6 de octubre de 2026. Base: PIA 1.15.5 con el ajuste previo del prompt semestral. Implementación local, sin API ni servidor obligatorio.

## Recorrido implementado

Una sola distribución compartida por cuatro pestañas, en este orden:

1. **Marco curricular**: referentes de las áreas del nivel y módulo, competencias, RdA, perfiles y descripción del módulo. Incluye consulta de la progresión entre sétimo, octavo y noveno. La vista Datos iniciales conserva los controles originales de marco temporal, diagnóstico, contexto, recursos, módulos y perfil de evaluación.
2. **Saberes e indicadores**: inventario completo y filtro por área. Puede organizarlo manualmente o preparar una consulta a IA antes de seleccionar. La respuesta se pega o importa como JSON, se comprueba estructuralmente y solo modifica la distribución cuando el docente aplica una alternativa como borrador. PIA no ejecuta un modelo de IA automáticamente.
3. **Distribución por semanas**: calendario editable, disponibilidad de 0, 1 o 2 lecciones, condiciones y recesos visibles; ubicación en lecciones pedagógicas y fases del Proyecto; integración de saberes y semanas no consecutivas. Mover un saber cambia su orden; reasignar semanas exige una decisión explícita. Las asignaciones incompatibles con un nuevo receso se conservan y se advierten para reubicarlas.
4. **Proyecto y mediación**: condiciones del Proyecto, mediación y evaluación por etapa. Situación problema y producto pueden permanecer pendientes. Etapa I conserva su catálogo propio; Etapa II y Etapa III recuperan únicamente los indicadores curriculares vinculados. La ayuda de IA prepara sugerencias de indicadores de evaluación con evidencia y criterio; el docente decide cuál usar y contextualizar. La Etapa III permite registrar necesidad, pruebas, retroalimentación, mejoras y apoyos DUA. El campo de asesoría provisional se identifica como no oficial y puede sustituirse.

La guía indica el siguiente paso y permite regresar. El cuaderno, iconos, colores y tarjetas reproducen el lenguaje visual de las imágenes acordadas. En celular las pestañas se distribuyen en dos filas y el calendario usa tarjetas; en escritorio muestra una tabla y un editor contextual. No se fuerza la tabla de escritorio dentro del ancho del celular.

## Un solo proceso y referentes protegidos

El mapa curricular es una vista opcional para consultar o editar la misma distribución. El prompt semestral mantiene su contrato A–H y desarrolla las decisiones guardadas por el docente. Incluye metodología, ejes transversales, saberes procedimentales, saberes actitudinales, DUA, progresión, evaluación y orientaciones docentes por etapa; distingue lo previsto de lo contextualizado. Guardar conserva decisiones y no certifica logros ni pertinencia pedagógica.

Los textos de PNFT_DATA, las referencias de línea base y los RdA de preescolar y primaria se conservan. Se ajustaron exclusivamente los cuatro RdA de III Ciclo a la redacción literal de la Guía docente para la Formación Tecnológica — Secundaria III Ciclo aportada, páginas 7–8. Los descriptores procedimentales y actitudinales se consultan literalmente desde el mismo referente, páginas 52–54. PIA no presenta los acuerdos provisionales de asesoría como indicadores oficiales.

Los porcentajes y componentes del perfil de evaluación se conservan. La previsión distingue trabajo cotidiano, tareas y Proyecto; una evidencia no debe puntuarse dos veces. PIA no registra calificaciones individuales. Los instrumentos se prevén y contextualizan antes de valorar; sus criterios y el instrumento deben comunicarse al estudiantado.

Los controles originales se trasladan dentro de secundaria y regresan a su ubicación al cambiar de ciclo. No se clonan. Preescolar y primaria mantienen sus recorridos y prompts.

## Verificación

- **312 pruebas automatizadas aprobadas**, incluidos fuente, compilación, alcance autorizado e integridad.
- **38 escenarios de navegador Chromium aprobados**, sin errores JavaScript: 20 de regresión y 18 específicos del rediseño.
- Los seis casos de sétimo, octavo y noveno, módulos 1 y 2: inventarios, áreas, RdA visibles antes de incluir saberes y consulta previa a IA.
- Importación de JSON mediante selector real de archivos, aplicación explícita, rechazo de propuesta obsoleta, selección editable, integración y semanas no consecutivas.
- Guardado JSON, carga, autoguardado y recuperación: calendario, distribución, evaluaciones y notas por etapa conservados.
- Prompt semestral y texto editado manualmente conservados; comparación exacta de 14 prompts de preescolar/primaria con la base.
- Word: vista previa y descarga real; PDF: vista previa y bytes PDF válidos. Se conserva la separación entre proyección y planeamiento semanal.
- Portable: descarga y apertura real con file://, estado embebido, módulos y marco temporal editables.
- Navegación por teclado, panel visible único, ausencia de IDs duplicados, tema oscuro y anchos de 390, 820 y 1440 píxeles.
- Cambio entre secundaria, II Ciclo, I Ciclo y preescolar: controles originales restaurados.

Las capturas en tests/redesign-captures corresponden a la implementación real. Los datos introducidos en ellas son casos de prueba editables, no una distribución curricular obligatoria ni un planeamiento validado. Las pruebas en navegador no equivalen a una prueba de usabilidad con docentes nuevos ni a ensayos en dispositivos físicos iPad/iPhone.

## Uso y archivos

Extraiga el ZIP y abra **index.html**, o **dist/portable/index.html**, en Chrome o Edge. Para ver el rediseño seleccione III Ciclo, nivel y módulo, y abra Proyección semestral. Los archivos de src son la fuente; index.html y dist son salidas generadas mediante npm run build. npm test reproduce la validación automatizada; los scripts de navegador requieren Playwright y un Chromium disponible.

Resultados: tests/secondary-browser-results.json y tests/secondary-tabs-browser-results.json. Capturas: tests/redesign-captures. Informe anterior de prompt: histórico; este documento describe la entrega vigente.

SHA-256 de las tres salidas HTML idénticas: `dffce4e654c037fdad4aae16505064aeae8d681890434589f85079e45fa5f568`.
