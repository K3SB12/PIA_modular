"""Create a concise, evidence-backed report; no changes to PIA runtime."""
from pathlib import Path
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root = Path(__file__).resolve().parents[1]
out = root.parents[1] / 'deliverables' / 'Informe-pruebas-PIA-secundaria-y-celular.docx'
teacher = json.loads((root/'tests/secondary-teacher-visual-results.json').read_text())
tabs = json.loads((root/'tests/secondary-tabs-browser-results.json').read_text())
base = json.loads((root/'tests/secondary-browser-results.json').read_text())
def counts(data):
    rows = data if isinstance(data,list) else data['results']
    return f"{sum(x['status']=='PASS' for x in rows)}/{len(rows)}"
d = Document()
s = d.sections[0]; s.page_width=Inches(8.5);s.page_height=Inches(11)
s.top_margin=s.bottom_margin=Inches(.75);s.left_margin=s.right_margin=Inches(.8)
for name in ['Normal','Title','Heading 1','Heading 2']:
    st=d.styles[name];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(11)
d.styles['Normal'].paragraph_format.space_after=Pt(7)
def p(text): d.add_paragraph(text)
def h(text): d.add_heading(text,level=1)
def table(headers,rows):
    t=d.add_table(rows=1,cols=len(headers));t.style='Table Grid'
    for c,v in zip(t.rows[0].cells,headers):
        c.text=v
        for r in c.paragraphs[0].runs:r.bold=True
        shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'EEEEEE');c._tc.get_or_add_tcPr().append(shade)
    for row in rows:
        for c,v in zip(t.add_row().cells,row):c.text=str(v)
    for row in t.rows:
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        for cell in row.cells:
            for par in cell.paragraphs:
                par.paragraph_format.space_after=Pt(5)
                for run in par.runs:run.font.size=Pt(10)

d.add_heading('PIA 1.15.5: pruebas de secundaria y celular',0)
p('Informe de validación interna · 6 de octubre de 2026, Costa Rica')
h('Resultado y alcance')
p('Se implementaron funciones faltantes del rediseño de secundaria y se corrigieron desbordamientos móviles de PIA en general, autorizados durante esta revisión. Fuera de secundaria, los ajustes son exclusivamente de presentación: no cambian contenidos curriculares, fórmulas, funciones, campos ni orden de las secciones aprobadas.')
table(['Comprobación','Resultado'],[
('Pruebas automatizadas de código y contratos','316/316; sin fallos'),
('Regresión de secundaria, persistencia y exportaciones',counts(base)),
('Pestañas, navegación, IA asistida y compatibilidad',counts(tabs)),
('Recorrido docente, seis referencias visuales y móvil',counts(teacher)),
('Errores JavaScript del recorrido docente',str(len(teacher['pageErrors']))),
])
h('Lo que significa esta validación')
p('Es un ensayo interno adoptando la perspectiva docente, no una evaluación realizada por docentes participantes ni una certificación del MEP. Se verificaron los referentes e inventarios de sétimo, octavo y noveno en ambos módulos. El recorrido detallado desarrolla una proyección de octavo, módulo 1, y una semana de planeamiento; no equivale a seis planeamientos semestrales completos.')
h('Correspondencia con las imágenes')
p('El ZIP contiene seis JSON de especificación visual, un JSON consolidado y las seis imágenes de referencia. Son reconstrucciones documentadas de lo visible y de los acuerdos, no código extraído de las imágenes. Las capturas de tests/teacher-evidence muestran la implementación real. No se afirma identidad píxel por píxel: cambian el contenido real, los estados y el tamaño de pantalla.')
d.add_page_break()
h('Ensayo de proyección y planeamiento')
table(['Decisión del ensayo','Comprobación'],[
('Octavo, módulo 1; 17 semanas','Se distribuye el inventario curricular mediante controles reales.'),
('Diagnóstico y disponibilidad','Diagnóstico de 2 lecciones; reserva no lectiva de 2; semana 16 con 0 lecciones. Tiempo neto comprobado: 30 lecciones.'),
('Proyecto en 6 semanas','Semanas 7, 8 y 9: Empatizar, Definir e Idear; 10–11: Prototipar; 12: Probar y Evaluar. Es ilustrativo, no obligatorio.'),
('Integración de dos áreas','Se vinculan saberes de programación y robótica conservando los indicadores oficiales por separado.'),
('Etapas II y III','Indicadores de evaluación diferenciados; rúbrica analítica prevista; comunicación al estudiantado pendiente, sin marcarla automáticamente.'),
('Semana 10 de planeamiento','Mediación con inicio, desarrollo y cierre, DUA, saberes procedimentales y actitudinales y ejes transversales.'),
('Situación problema y producto','Permanecen abiertos para contextualizar con el estudiantado; el ensayo no prescribe un tema ni un producto único.'),
])
h('Guardado, carga y salidas')
p('Se verificaron descarga e importación real del JSON, autoguardado y recuperación, prompt editado, estado embebido en versión portable, vista de impresión de la proyección y salida del planeamiento a Word y PDF. La ruta curricular opcional y el prompt semestral utilizan la misma distribución, sin imponer un segundo proceso.')
p('La salida Word de PIA es el formato .doc ya existente; esta entrega no sustituye ni reprograma ese exportador. Se revisó el contenido descargado y la ventana imprimible; el PDF se generó con Chromium. No se ensayó Microsoft Word ni una impresora física.')
h('Precauciones pedagógicas')
p('Que una distribución se guarde no demuestra que todos los desempeños sean alcanzables con los recursos y el grupo. Antes de usarla, revisar carga de trabajo, conocimientos previos, disponibilidad de herramientas y evidencias. Diferenciar la evidencia de Trabajo cotidiano y Proyecto para no duplicar puntos. Los indicadores de evaluación propuestos siguen sujetos a revisión docente; no pasan a ser indicadores de logro oficiales.')
d.add_page_break()
h('Responsividad general: correcciones acotadas')
table(['Desbordamiento detectado','Ajuste de presentación'],[
('Datos administrativos en tres columnas','Apilado del cuadro en celular; controles con anchura flexible.'),
('Estado del plan y encabezado de proyección','Ajuste de filas y texto; se conservan los mismos controles.'),
('Botones inferiores','Pasan a varias filas sin quedar fuera del ancho visible.'),
('Navegación de 17 semanas','Botones distribuidos en varias filas; mismos destinos y selección.'),
('Áreas, RdA y saberes semanales','Columnas apiladas en pantallas pequeñas.'),
('Descripciones emergentes de saberes','Cuadro ajustado al ancho visible, sin modificar los descriptores.'),
('Pestañas de marco curricular en secundaria','Filtros en dos columnas; textos visibles, sin botones fuera de pantalla.'),
])
h('Dispositivos simulados')
p('Se probaron anchos de 320, 360, 390 y 430 px en las pestañas de secundaria, además de orientación horizontal 844 × 390. El recorrido general comprueba preescolar, I ciclo, II ciclo y III ciclo en esos cuatro anchos: 16 combinaciones. Los valores de anchura y controles fuera de pantalla están registrados en tests/secondary-teacher-visual-results.json.')
findings=teacher['responsiveFindings']
p(f"En las {len(findings)} combinaciones generales registradas, la anchura del documento no supera la pantalla y no se detectan controles visibles fuera de ella. La tabla de distribución conserva su contenedor desplazable cuando es necesario; esto no equivale a un desbordamiento de toda la página.")
h('Límites y prueba final recomendada')
p('Las pruebas son con Chromium y pantallas emuladas. No garantizan aún el comportamiento de Safari/iOS, teclado táctil, lector de pantalla o un dispositivo físico. Se recomienda un pilotaje breve: abrir la copia entregada en el celular, seleccionar nivel y módulo, editar una semana, guardar JSON y volver a cargarlo. Las capturas y el JSON de ensayo incluidos permiten reproducir el recorrido.')
h('Dónde encontrar las evidencias')
p('docs/contratos-visuales-secundaria/: seis especificaciones e imágenes. tests/teacher-evidence/: capturas, prompt, JSON de ensayo y exportaciones. tests/: resultados de las tres suites de navegador. CURRENT.sha256: huellas de las salidas HTML equivalentes. La entrega conserva una copia separada de la versión anterior.')
out.parent.mkdir(exist_ok=True);d.save(out);print(out)
