import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

async function sources(){
  const templateNames=(await readdir(new URL('../src/templates/',import.meta.url))).filter(name=>name.endsWith('.html'));
  const jsNames=(await readdir(new URL('../src/',import.meta.url),{recursive:true})).filter(name=>name.endsWith('.js'));
  const templates=(await Promise.all(templateNames.map(name=>read(`src/templates/${name}`)))).join('\n');
  const javascript=(await Promise.all(jsNames.map(name=>read(`src/${name}`)))).join('\n');
  return {templates,javascript};
}

test('cada botón está conectado por id, onclick o un delegado reconocido',async()=>{
  const {templates,javascript}=await sources();
  const buttons=[...templates.matchAll(/<button\b([^>]*)>/gi)].map(match=>match[1]);
  assert.ok(buttons.length>=100,'La auditoría debe cubrir la interfaz completa');
  const delegated=['data-pia-help','data-pia-review-ai','data-pia-route-step'];
  for(const attributes of buttons){
    const id=attributes.match(/\bid="([^"]+)"/)?.[1]||'';
    const onclick=attributes.match(/\bonclick="([^"]+)"/)?.[1]||'';
    const delegatedAttribute=delegated.find(name=>attributes.includes(name+'='));
    assert.ok(id||onclick||delegatedAttribute,`Botón sin contrato de acción: ${attributes}`);
    if(id)assert.ok(javascript.includes(`'${id}'`)||javascript.includes(`"${id}"`),`Botón #${id} sin referencia JavaScript`);
    if(onclick){
      const functionName=onclick.match(/^([A-Za-z_$][\w$]*)\s*\(/)?.[1];
      assert.ok(functionName,`onclick no reconocido: ${onclick}`);
      assert.match(javascript,new RegExp(`function\\s+${functionName}\\s*\\(|(?:window\\.)?${functionName}\\s*=`),`Función ${functionName} ausente`);
    }
  }
});

test('los selectores de archivo activos conservan el gesto directo de la persona usuaria',async()=>{
  const {javascript}=await sources();
  assert.match(javascript,/function openPlanFilePicker\(\)/);
  assert.match(javascript,/abrirPlan=openPlanFilePicker/);
  assert.match(javascript,/const input=\$\('piaPlanFileInput'\)/);
  assert.match(javascript,/input\.click\(\);\s*return false;/);
  assert.match(javascript,/\$\('piaRouteImportJsonButton'\)\?\.addEventListener\('click',\(\)=>\$\('piaRouteImportJson'\)\?\.click\(\)\)/);
});

test('las acciones principales mantienen sus funciones declaradas',async()=>{
  const {javascript}=await sources();
  for(const name of ['nuevoPlan','abrirPlan','ejecutarGuardarNormal','ejecutarGuardarOffline','mostrarOpcionesExportar','confirmarExportacion','generarPromptCompleto','agregarSemanaManual','copiarPrompt','copiarPromptSemana']){
    assert.match(javascript,new RegExp(`function\\s+${name}\\s*\\(`),`Falta la función principal ${name}`);
  }
});
