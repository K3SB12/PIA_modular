import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
async function runtime(){
  const ctx=vm.createContext({console});
  for(const file of ['src/data/pnft-data.js','src/data/project-component-catalog.js','src/domain/projection/projection-core.js'])vm.runInContext(await read(file),ctx,{filename:file});
  vm.runInContext('globalThis.qa={data:PNFT_DATA,projection:PIAProjectionCore,secondary:PIASecondaryPlanningCore}',ctx);
  return ctx.qa;
}

for(const [level,module,count] of [['7°','Módulo 1',18],['7°','Módulo 2',15],['8°','Módulo 1',16],['8°','Módulo 2',12],['9°','Módulo 1',10],['9°','Módulo 2',10]]){
  test(`proyección ${level} ${module}: conserva inventario, distribución no consecutiva y evaluación prevista`,async()=>{
    const {data,projection,secondary}=await runtime();
    const areas=Object.keys(data[level][module]);
    const concepts=projection.listConcepts(data,level,[module],areas);
    assert.equal(concepts.length,count);
    assert.equal(new Set(concepts.map(c=>c.id)).size,count);
    const assignments={};
    for(const [index,c] of concepts.entries())assignments[c.id]=secondary.normalizeAssignment({role:index%2?'integrated':'pedagogical',weeks:[2,6,10],phaseIds:index%2?['prototype','test-evaluate']:[],secondary:{mediacion:'Mediación prevista revisable',procedural:['depura'],attitudinal:['aprender'],axes:['pensamiento'],evaluations:{prototype:{indicator:'Desempeño previsto',evidence:'Evidencia prevista',criterion:'Criterio',descriptors:'Niveles editables',points:'3',instrument:'Rúbrica',prepared:false,communicated:false,status:'planned'}}}});
    const fixture={schemaVersion:6,pia:{...projection.defaultEnhancements(),projection:{modules:[module],areas,conceptIds:concepts.map(c=>c.id)},methodology:{routeAssignments:assignments},secondaryPlanning:{order:concepts.map(c=>c.id),calendarOverrides:{5:{lessons:0,reason:'Semana Santa'},8:{lessons:1,reason:'Disponibilidad parcial'}},guideStep:4,view:'weeks'}}};
    const restored=projection.migrate(JSON.parse(JSON.stringify(fixture)));
    for(const [id,assignment] of Object.entries(assignments))for(const [key,value] of Object.entries(assignment))assert.deepEqual(plain(restored.methodology.routeAssignments[id][key]),plain(value),`${id}: conserva ${key}`);
    assert.deepEqual(plain(restored.secondaryPlanning),plain(fixture.pia.secondaryPlanning));
    assert.equal(restored.evaluation.projectPlanning.problem,'');
    assert.equal(restored.evaluation.projectPlanning.expectedSolution,'');
    for(const c of concepts){const src=data[level][module][c.area].saberes.find(v=>v.nombre===c.name);assert.deepEqual(plain(c.indicators),plain(src.indicadores));}
  });
}

test('semanas: acepta rangos y semanas separadas, rechaza recesos y valores fuera del periodo',async()=>{
  const {secondary}=await runtime();
  assert.deepEqual(plain(secondary.parseWeeks('2, 6, 10',17,{})),[2,6,10]);
  assert.deepEqual(plain(secondary.parseWeeks('7-9',17,{})),[7,8,9]);
  assert.throws(()=>secondary.parseWeeks('0,18',17,{}));
  assert.throws(()=>secondary.parseWeeks('5',17,{5:{lessons:0,reason:'Semana Santa'}}));
  assert.deepEqual(plain(secondary.parseWeeks('8',17,{8:{lessons:1,reason:'Parcial'}})),[8]);
});

test('calendario: distingue semana disponible, receso y disponibilidad parcial sin eliminar la semana',async()=>{
  const {secondary}=await runtime();
  const rows=secondary.calendar(17,'2027-02-08',{5:{lessons:0,reason:'Semana Santa'},8:{lessons:1,reason:'Feriado'}});
  assert.equal(rows.length,17);
  assert.equal(rows[0].week,1);assert.equal(rows[0].lessons,2);
  assert.equal(rows[4].lessons,0);assert.equal(rows[4].reason,'Semana Santa');
  assert.equal(rows[7].lessons,1);
  assert.equal(rows.reduce((sum,row)=>sum+row.lessons,0),31);
});

test('mover un saber no modifica semanas ni contenido oficial',async()=>{
  const {secondary}=await runtime();
  const assignments={a:secondary.normalizeAssignment({weeks:[2,6]}),b:secondary.normalizeAssignment({weeks:[3]}),c:secondary.normalizeAssignment({weeks:[8]})};
  const before=JSON.stringify(assignments);
  const moved=secondary.move(['a','b','c'],'b','up',assignments);
  assert.deepEqual(plain(moved),['b','a','c']);
  assert.equal(JSON.stringify(assignments),before);
});

test('guardar, autoguardar y cargar usan el mismo estado con todos los campos nuevos',async()=>{
  const sources=await Promise.all(['src/data/pnft-data.js','src/data/project-component-catalog.js','src/domain/projection/projection-core.js','src/application/enhancements.js'].map(read));
  const storage=new Map();
  const ctx=vm.createContext({console,localStorage:{setItem:(key,value)=>storage.set(key,value)},setTimeout:()=>0});
  for(const source of sources.slice(0,3))vm.runInContext(source,ctx);
  vm.runInContext(`var state=PIAProjectionCore.defaultEnhancements(),loading=false,dirty=true,activeWeekIndex=0,showAllWeeks=false;const STORAGE_KEY='pia.plan.autosave.v6';const clone=value=>JSON.parse(JSON.stringify(value));const $=()=>null;function collectStateFromUI(){}function sanitizeWeeks(value){return value;}function renderState(){}function scheduleWeekNavigator(){}function obtenerDatosPlan(){return {nivel:'8°',semanas:[]};}function cargarPlan(){}function ejecutarGuardarNormal(){globalThis.manual=JSON.stringify(obtenerDatosPlan());}`,ctx);
  const source=sources[3],start=source.indexOf('const baseGet=obtenerDatosPlan;'),end=source.indexOf('const baseGeneral=generarPromptCompleto;',start);
  assert.ok(start>=0&&end>start,'Wrappers de persistencia presentes');
  vm.runInContext(source.slice(start,end),ctx);
  const autoStart=source.indexOf('function saveAutosave()'),autoEnd=source.indexOf('function renderIdentity()',autoStart);
  vm.runInContext(source.slice(autoStart,autoEnd),ctx);
  vm.runInContext(`state.secondaryPlanning={order:['uno'],calendarOverrides:{5:{lessons:0,reason:'Semana Santa'}},guideStep:4,view:'weeks'};state.methodology.routeAssignments.uno=PIASecondaryPlanningCore.normalizeAssignment({role:'integrated',weeks:[2,6,10],phaseIds:['prototype','test-evaluate'],secondary:{mediacion:'Mediación nueva',procedural:['depura'],attitudinal:['aprender'],axes:['pensamiento'],evaluations:{prototype:{indicator:'IE previsto',evidence:'Prototipo',criterion:'Criterio',descriptors:'Niveles',points:'3',instrument:'Rúbrica',prepared:true,communicated:true,status:'contextualized'},'test-evaluate':{indicator:'IE final',evidence:'Registro pruebas',criterion:'Contrasta',descriptors:'Niveles finales',points:'6',instrument:'Escala',prepared:false,communicated:false,status:'provisional'}}}});ejecutarGuardarNormal();saveAutosave();globalThis.expected=JSON.parse(manual);cargarPlan(JSON.parse(manual));globalThis.restored=obtenerDatosPlan();`,ctx);
  const auto=JSON.parse(storage.get('pia.plan.autosave.v6'));
  assert.deepEqual(auto,plain(ctx.expected));
  assert.deepEqual(plain(ctx.restored.pia.secondaryPlanning),auto.pia.secondaryPlanning);
  const before=auto.pia.methodology.routeAssignments.uno,after=plain(ctx.restored.pia.methodology.routeAssignments.uno);
  for(const [key,value] of Object.entries(before))assert.deepEqual(after[key],value);
  assert.equal(after.secondary.evaluations['test-evaluate'].indicator,'IE final');
});

test('grupos se movilizan juntos y las etapas no adquieren nombres abreviados',async()=>{
  const {secondary}=await runtime();
  const assignments={a:{groupId:'g'},b:{groupId:'g'},c:{},d:{}};
  assert.deepEqual(plain(secondary.move(['a','b','c','d'],'a','down',assignments)),['c','a','b','d']);
  for(const label of Object.values(secondary.phaseLabels))assert.match(label,/^Etapa /);
});

test('portable incrusta el mismo JSON y protege cierre de script en textos docentes',async()=>{
  const source=await read('src/application/enhancements.js');
  const line=source.split('\n').find(value=>value.includes('descargarVersionPortable=function(){'));
  assert.ok(line,'Contrato portable existente');
  const snapshot={schemaVersion:6,pia:{secondaryPlanning:{order:['a'],guideStep:3,view:'weeks',calendarOverrides:{5:{lessons:0,reason:'Receso'}}},methodology:{routeAssignments:{a:{weeks:[2,6],phaseIds:['prototype'],secondary:{mediacion:'Texto </script> conservado'}}}}}};
  const blobs=[];let marker;
  const document={body:{appendChild(value){marker=value;}},createElement(type){return type==='script'?{remove(){}}:{click(){}};},documentElement:{cloneNode(){return {querySelector(){return null;},get outerHTML(){return `<html><body><script id="${marker.id}">${marker.textContent}</script></body></html>`;}};}}};
  const ctx=vm.createContext({console,document,Blob,URL:{createObjectURL(value){blobs.push(value);return 'blob:test';},revokeObjectURL(){}},obtenerDatosPlan:()=>snapshot,setTimeout:()=>0,notify(){}});
  vm.runInContext(line+';descargarVersionPortable();',ctx);
  assert.equal(blobs.length,1);
  const html=await blobs[0].text();
  const encoded=html.match(/window\.__PIA_EMBEDDED_PLAN__=(.*);<\/script>/)?.[1];
  assert.ok(encoded,'JSON incrustado presente');
  assert.ok(!encoded.includes('</script>'));
  assert.deepEqual(JSON.parse(encoded),snapshot);
});

test('planes históricos conservan rangos y contextualización; otros ciclos no reciben asignaciones',async()=>{
  const {projection,secondary}=await runtime();
  const legacy=secondary.normalizeAssignment({role:'integrated',phaseId:'prototype',weekStart:7,weekEnd:9,note:'Texto histórico',evidence:'Evidencia anterior'});
  assert.deepEqual(plain(legacy.weeks),[7,8,9]);
  assert.ok(legacy.phaseIds.includes('prototype'));
  assert.equal(legacy.note,'Texto histórico');
  const primary=projection.migrate({nivel:'4°',pia:{projection:{modules:['Módulo 1'],conceptIds:['histórico']},aiPrompts:{general:'Texto editado'}}});
  assert.deepEqual(plain(primary.projection.conceptIds),['histórico']);
  assert.equal(primary.aiPrompts.general,'Texto editado');
  assert.deepEqual(plain(primary.methodology.routeAssignments),{});
});

test('cambio de calendario conserva asignaciones y emite aviso revisable',async()=>{
  const {data,projection,secondary}=await runtime();
  const concepts=projection.listConcepts(data,'9°',['Módulo 1'],Object.keys(data['9°']['Módulo 1']));
  const assignments={[concepts[0].id]:secondary.normalizeAssignment({role:'pedagogical',weeks:[5]})};
  const before=JSON.stringify(assignments);
  const warnings=secondary.audit(concepts,assignments,17,{5:{lessons:0,reason:'Semana Santa'}});
  assert.ok(Array.isArray(warnings)&&warnings.length>0);
  assert.equal(JSON.stringify(assignments),before);
});

test('conserva las correcciones autorizadas de II Ciclo y sistema operativo de sexto',async()=>{
  const {data}=await runtime();
  const ctx=vm.createContext({});
  vm.runInContext(await read('src/data/rda-por-ciclo.js')+';globalThis.rda=RDA_POR_CICLO;',ctx);
  assert.equal(ctx.rda['II Ciclo']['Ciencia de datos e Inteligencia artificial'],'Reconoce cómo se usa la inteligencia artificial; cómo mediante técnicas básicas se recolectan, analizan y representan los datos en tablas y gráficos sencillos.');
  const os=data['6°']['Módulo 1']['Apropiación tecnológica y Digital'].saberes.find(item=>item.nombre==='Sistema operativo');
  assert.deepEqual(plain(os.indicadores),['Identificar herramientas del sistema operativo como el administrador de tareas, la limpieza de archivos temporales y la gestión de memoria, comprendiendo su uso en la optimización del rendimiento del equipo informático.']);
});

test('actividad del calendario se guarda durante escritura sin esperar pérdida de foco',async()=>{
  const source=await read('src/application/enhancements.js');
  const start=source.indexOf('function secondaryMount()'),end=source.indexOf('function secondaryRender()',start);
  const listeners={},model={calendarOverrides:{}};
  const host={setAttribute(){},addEventListener(name,handler){listeners[name]=handler;}};
  const ctx=vm.createContext({document:{createElement:()=>host},secondaryState:()=>model,secondaryChange(){},markDirty(){},secondaryClick(){},$:(id)=>id==='piaProjectPlanningWrap'?{before(){}}:null});
  vm.runInContext(source.slice(start,end)+';secondaryMount();',ctx);
  const target={tagName:'TEXTAREA',dataset:{secondaryCalendar:'3',field:'activity'},value:'Práctica y profundización',matches(selector){return selector.split(',').some(part=>part.trim().startsWith('textarea')&&part.includes('[data-secondary-calendar]'));}};
  listeners.input({target});
  assert.equal(model.calendarOverrides[3]?.activity,'Práctica y profundización');
});

test('borrar un indicador de evaluación previsto no deja una versión anterior activa',async()=>{
  const source=await read('src/application/enhancements.js');
  const start=source.indexOf('function syncSecondaryProjectRecord('),end=source.indexOf('function secondarySetIncluded(',start);
  const records={prototype:{achievementIndicators:[]},'test-evaluate':{achievementIndicators:[]}};
  const ctx=vm.createContext({state:{projection:{conceptIds:['a']},evaluation:{projectPlanning:{selectedPhaseIds:[]}}},PIAProjectComponentCatalog:{CATALOG_VERSION:'qa'},ensureProjectionPhaseRecord:phase=>records[phase]});
  vm.runInContext(source.slice(start,end),ctx);
  const concept={id:'a',indicators:['Indicador oficial'],area:'Área',module:'Módulo 1',name:'Saber'};
  const assignment={phaseIds:['prototype'],secondary:{evaluations:{prototype:{indicator:'IE anterior'},'test-evaluate':{indicator:''}}}};
  ctx.concept=concept;ctx.assignment=assignment;
  vm.runInContext('syncSecondaryProjectRecord(concept,assignment);',ctx);
  assignment.secondary.evaluations.prototype.indicator='';
  vm.runInContext('syncSecondaryProjectRecord(concept,assignment);',ctx);
  const ie=records.prototype.achievementIndicators[0].evaluationIndicators[0];
  assert.ok(ie.teacherText===''||ie.selected===false,'La versión anterior puede conservarse históricamente, pero no seguir activa');
});
