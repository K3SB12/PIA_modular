import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

async function openingFunction(){
  const source=await read('src/application/enhancements.js');
  const match=source.match(/function openPlanFilePicker\(\)\{([\s\S]*?)\n            \}\n            const methodologyMissions/);
  assert.ok(match,'Debe localizarse la función segura de apertura');
  return `function openPlanFilePicker(){${match[1]}\n}`;
}

test('Abrir y Continuar usan un selector persistente y lo activan en el clic original',async()=>{
  const [template,enhancements,source]=await Promise.all([
    read('src/templates/enhancements.html'),
    read('src/application/enhancements.js'),
    read('src/application/enhancements.js')
  ]);
  assert.match(template,/id="piaPlanFileInput"[^>]*type="file"[^>]*application\/json/);
  assert.match(source,/function openPlanFilePicker\(\)/);
  assert.match(source,/\n                input\.click\(\);\n                return false;/);
  assert.match(source,/abrirPlan=openPlanFilePicker/);
  assert.match(enhancements,/\$\('piaWelcomeLoad'\)\?\.addEventListener\('click',\(\)=>abrirPlan\(\)\)/);
  assert.doesNotMatch(enhancements,/piaWelcomeLoad'\)\?\.addEventListener\('click',\(\)=>\{setWelcomeVisible\(false\)/);
});

test('cancelar conserva la portada y elegir un JSON carga el plan antes de ocultarla',async()=>{
  const input={value:'anterior',files:[],clicks:0,onchange:null,click(){this.clicks++;}};
  const welcome={hidden:false};
  let loaded=null,scrolled=false,dispatched=false;
  const context=vm.createContext({
    $:id=>id==='piaPlanFileInput'?input:id==='piaWelcome'?welcome:null,
    document:{
      getElementById:id=>id==='piaPlanFileInput'?input:id==='piaWelcome'?welcome:null,
      querySelector:selector=>selector==='.container'?{scrollIntoView(){scrolled=true;}}:null,
      dispatchEvent(){dispatched=true;}
    },
    cargarPlan:(plan)=>{loaded=plan;},
    notify:()=>{},
    setWelcomeVisible:visible=>{welcome.hidden=!visible;},
    console,
    CustomEvent:class {constructor(type,options){this.type=type;this.detail=options?.detail;}},
    FileReader:class {readAsText(file){this.onload({target:{result:file.contents}});}}
  });
  vm.runInContext(`${await openingFunction()};globalThis.openPlan=openPlanFilePicker;`,context);

  context.openPlan();
  assert.equal(input.clicks,1,'El selector debe activarse sin temporizador');
  assert.equal(welcome.hidden,false,'Abrir el selector no debe ocultar la portada');
  input.onchange({target:input});
  assert.equal(welcome.hidden,false,'Cancelar la selección conserva la portada');

  input.files=[{name:'planeamiento.JSON',contents:'{"schemaVersion":6,"semanas":[]}'}];
  input.onchange({target:input});
  assert.equal(loaded.schemaVersion,6);
  assert.equal(welcome.hidden,true);
  assert.equal(scrolled,true);
  assert.equal(dispatched,true);
});
