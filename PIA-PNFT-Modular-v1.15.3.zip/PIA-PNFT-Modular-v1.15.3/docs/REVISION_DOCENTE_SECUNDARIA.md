# Revisión docente de selección y distribución curricular secundaria

## Fundamento de la revisión
Fuentes leídas: guía paso a paso (secciones 8 a 15, 20 a 26), guía docente III ciclo versión suministrada 20261001 y Excel Análisis de módulos y proyección de indicadores 9°. El Excel es un ejemplo contextual de asesores, no un calendario oficial ni una organización obligatoria.

## Seis escenarios de aceptación
Todos los escenarios mantienen problema y prototipo pendientes al inicio. Todos conservan el inventario completo del módulo, aunque solo un subconjunto se vincule al proyecto. Las semanas son condiciones de prueba, no cronogramas curriculares obligatorios.

### D1 Sétimo Módulo 1
- 17 semanas declaradas; semana 6 receso sin lecciones y semana 10 parcial con una lección. Diagnóstico semana 1.
- Integrar variable y estructuras condicionales dentro de Programación y Algoritmos; ubicar en lecciones 2–3 y Etapa II Desarrollo 8–9; Etapa III Final 12 para pruebas. Poder asignar semanas separadas 3, 8 y 12 a un indicador.
- Establecer otro vínculo editor de gráficos + entorno de programación, solo si existe mediación y edición que evidencien ambos indicadores. Evitar que usar una imagen acredite el indicador de gráficos automáticamente.
- Etapa I Inicial conserva los indicadores propios del componente Proyecto; Empatizar semana 4, Definir e Idear semana 5 como decisión de ejemplo.
- Mover conjunto sin cambiar semanas automáticamente; modificar luego una semana de un integrante sin perder el grupo.
- Prever IE para condicionales sin escribir problema ni producto. Etapa II utiliza una estructura condicional pertinente; Etapa III contrasta respuestas con casos previstos. Editar después de Idear y marcar contextualizado.
- Aceptación: receso visible e inasignable; parcial reduce tiempo; aprendizaje pendiente no desaparece; no nueva lista de IL exclusivos de etapas; no tema ni producto autoimpuesto.

### D2 Sétimo Módulo 2
- 16 semanas; semana 5 sin lecciones por actividad institucional; semana 11 parcial. Diagnóstico 1.
- Integración de misma área: navegador + buscador + referencias bibliográficas mediante búsqueda y organización fundamentada de información. Sin requerir que los tres compartan idénticas semanas.
- Integración de distintas áreas: productividad + dato, si los indicadores seleccionados efectivamente se evidencian. Procedimientos/funciones se desarrollan en lecciones específicas y pueden vincularse al proyecto cuando la alternativa lo permita; no todo debe ir al proyecto.
- Etapa I Inicial semanas 3 y 6 (no consecutivas), Etapa II Desarrollo 8–10, Etapa III Final 13–14, como escenario variable.
- Prever un proyecto sin programación, conservando oportunidades de ejecución de procedimientos/funciones en lecciones. No eliminar programación del inventario por elegir solución no programada.
- Aceptación: clasificación de formato no impone solución; se puede finalizar proyección con producto pendiente; fuentes oficiales accesibles y términos saberes procedimentales / saberes actitudinales.

### D3 Octavo Módulo 1
- 18 semanas; receso semana 7; semanas 9 y 10 parciales. Diagnóstico 1 identifica manejo desigual de estructuras y eventos de sétimo.
- Integrar microcontrolador + circuito eléctrico + electrónica y entorno de programación de mecanismos. El conjunto tiene semanas 4, 8 y 11–13 según necesidad, con lecciones previas y vínculo Etapa II Desarrollo.
- Multimedia se ubica en lecciones y eventualmente Etapa III Final si hay edición de audio/video con criterios técnicos; no se acredita solo por registrar un video sin edición.
- Agregar observación diagnóstica y apoyos de acceso, sin presumir dominio por haber cursado sétimo.
- Ejecutar orientación guiada, salir en paso 3 y retomar sin repetir selección.
- Aceptación: no requiere sensores de Módulo 2 como obligatorio; diagnóstico y DUA visibles; tiempo parcial advierte carga; preserva exacto texto curricular; mediación y evidencias separadas.

### D4 Octavo Módulo 2
- 15 semanas; semana 4 receso; semana 12 parcial.
- Integrar hoja de cálculo + recolección de datos entre ATD y Ciencia de datos e IA. Independientemente integrar colección de datos + sensor/actuador cuando sea pertinente.
- Un grupo puede compartir semanas 6–8; un indicador del grupo se añade también a semana 10. Separar grupo conserva indicadores y ubicaciones.
- Etapa I Inicial 2–3, lecciones 5–6, Etapa II Desarrollo 7–10, Etapa III Final 13–14 como ejemplo.
- Prever IE distintos en Etapa II y Etapa III; mismo IL no significa mismos puntos por misma evidencia. Cambiar alternativa después de Idear obliga a revisar vínculo, evidencia e instrumento, sin borrar IL del currículo.
- Aceptación: funciones de grupo accesibles por teclado; avisos informativos no imponen agrupación; auto/co evaluación no se convierte en puntos agregados automáticamente.

### D5 Noveno Módulo 1
- 17 semanas; Semana Santa identificada explícitamente como receso semana 6; disponibilidad parcial semana 15. No copiar 17 semanas del Excel automáticamente.
- Algoritmo en lecciones 2 y 3 para desarrollo/profundización. Dato/almacenamiento en lecciones 7 y 14; eventual tarea como oportunidad complementaria, no sustituto de mediación.
- Integrar microcontrolador + sensor + actuador + prototipos en Etapa II Desarrollo 8–12. Distribuir cada integrante si requiere diferente tiempo. Movimiento puede adelantarse si lo necesita la solución, no copiar su posición 16 del Excel.
- Etapa I Inicial Empatizar 4, Definir/Idear 5; Etapa III Final 13 y 16 con pruebas, hallazgos y decisiones; no imponer feria, iluminación ni prototipo específico.
- Aceptación: distinguir producto comunicativo de Definir de prototipo; el grupo completo no acredita automáticamente logros individuales; indicadores curriculares literales; prácticas de prueba contextualizadas sin exigir inventar fallas.

### D6 Noveno Módulo 2
- 14 semanas; semana 8 sin lecciones; semana 4 parcial.
- Integrar base de datos + herramientas de creación de contenido cuando exista relación demostrable; integrar autoría + plataformas + multimedia para producciones fundamentadas; articular IA generativa y desafíos con evidencia de análisis crítico.
- No inventar nuevos indicadores obligatorios de Programación/CFR porque no aparezcan nuevos saberes de esas áreas en el módulo. Se permite recuperar aprendizajes anteriores, identificados como recuperación.
- Etapa I Inicial 2 y 3; Etapa II Desarrollo 6–7 y 9; Etapa III Final 11–12. Mantener problema/producto abiertos; prever análisis o recurso digital sin imposición de robot.
- Aceptación: consulta repertorio correcto Módulo 2; cambio de módulo requiere contexto claro para no arrastrar selecciones incompatibles; mismos datos en inventario, vista semanal, ruta, prompt, guardado y exportación.

## Criterios transversales
1. Vocabulario oficial: saberes conceptuales, saberes procedimentales, saberes actitudinales, indicador de logro, indicador de evaluación, lecciones pedagógicas. No convertir preparación/aplicación/comprobación en categorías nuevas.
2. Nombres completos: Etapa I Inicial — Empatizar, Definir e Idear; Etapa II Desarrollo — Prototipar; Etapa III Final — Probar y Evaluar.
3. Todos los indicadores del módulo visibles; ninguno autoasignado a Etapa II o Etapa III por seleccionar todo.
4. Etapa I usa 3 indicadores de logro propios y 5 indicadores de evaluación del documento de Proyecto; vínculos curriculares no los sustituyen.
5. Previsión evaluativa posible sin problema/producto; estado previsto/contextualizado claro; criterios del instrumento preparados y comunicados antes de la valoración correspondiente.
6. PIA no otorga puntos por selección; no califica solo producto; mantiene la relación IL→IE→evidencia→criterio→instrumento.
7. Calendario real y tiempo parcial; receso visible; semana disponible vacía se reconoce como pendiente.
8. Integración explicada; misma semana no equivale a integración. Desagrupar no elimina saberes.
9. Subir/bajar no cambia semanas silenciosamente; semanas separadas, rangos y varias semanas permitidos.
10. Guardado conserva selección, orden, grupos, semanas, mediación, evidencia, estados pendientes, punto de guía; mismo contrato en export/import/reset/print/prompt.
11. Ruta es continuación opcional de mismos datos; no doble selección obligatoria.
12. Otros ciclos sin cambios; RdA 4/5/6 y IL sexto sistemas operativos preservados exactamente.
13. Ayudas breves, opcionales, fuente consultable; guiar decisión siguiente, no exigir un único recorrido.
14. Avisos de continuidad entre niveles no afirman ausencia definitiva en otro módulo sin comprobación.
15. El ejemplo de asesores no determina contexto, calendario, fases por semana, formato ni producto de otros docentes.

## Riesgos que deben bloquear aceptación pedagógica
- Campo de nombre/producto obligatorio o producto seleccionado automáticamente.
- Todos los indicadores puestos en ambas etapas al seleccionar módulo.
- Asignar desarrollo curricular a semana sin lecciones.
- IE generado presentado como texto oficial.
- Cambiar verbo/redacción oficial para acomodar producto.
- Trasladar un saber de Módulo 1 a Módulo 2 por simple movimiento.
- Prometer aprendizaje logrado/certificación RdA a partir de cobertura marcada.
- Borrar decisiones previas al importar un planeamiento anterior.

## Estado de verificación
Escenarios y criterios documentales preparados. Revisión de implementación pendiente de entrega de versión por agente desarrollador. No se ha dado por aprobado código todavía.

## Revisión concreta de implementación
Fecha de revisión: 4 octubre 2026. Archivos inspeccionados: enhancements.js bloque secundario y projection-core.js. Revisión estática de texto, modelos y flujo; no se afirma prueba de interacción en navegador por este agente.

### Comportamientos pertinentes implementados
- Inventario separado de ubicación: seleccionar saber no lo vincula al proyecto.
- Etapas rotuladas completas, cinco fases y lecciones pedagógicas seleccionables.
- IE previsto/contextualizado por fase, evidencia, criterio, descriptores, instrumento, puntos previstos y comunicación previa.
- Referentes propios Etapa I desplegables; no sustituye con currículo tecnológico.
- Problema/prototipo pendientes explícitos, distinto producto comunicativo de Definir.
- Calendario editable 0/1/2 lecciones; receso conserva asignación previa y pide revisión; nuevas asignaciones bloqueadas a semana sin lecciones.
- Movimiento conserva semanas; vínculo entre áreas; separación sin borrar saber; deshacer.
- Módulo de ruta comparte routeAssignments y consulta de Proyecto usa sólo vínculos seleccionados.
- Prompts secundarios protegidos por condición III Ciclo 7/8/9.

### Hallazgos comunicados al desarrollador
1. Filtrar inventario incluido en vista semanal: actualmente asignaciones conservadas de saber excluido pueden mostrarse como previstas.
2. Una sola fase por semana limita dos fases en un bloque. Se requiere selección múltiple de fases o explicación y anotación visible, sin perder relación con fases del saber.
3. Prompt necesita inventario disponible no incluido como pendiente de revisión; seleccionados solos no permiten comprobar cobertura.
4. Prompt/impresión deben mostrar situación/prototipo existentes y nombre/aportes del vínculo, no únicamente groupId.
5. Un IE de fase por saber se replica a todos sus IL. Si un saber contiene varios IL, pedir revisar explícitamente correspondencia individual, sin suponer que un IE único evidencia todos.
6. Guía seis pasos es adecuada como primera versión, pero no detecta automáticamente fin de decisión; fuentes nombradas no enlazadas. Mejorar ejemplos breves y fundamento consultable.

### Resultado por escenario
D1 a D6 representables en inventario, semanas y fases de saber. Recorridos con Definir+Idear en misma semana necesitan resolver hallazgo 2. Proyección con saber excluido/pendiente necesita hallazgos 1 y 3 para evitar cobertura aparente. Evaluación provisional sin producto está resuelta. Integración puede establecerse, pero su explicación debe persistir y salir en consulta/impresión (hallazgo 4). Modelo de varios IL por saber requiere comprobación hallazgo 5.

No se recomienda declarar aprobación pedagógica plena sin corregir 1/3/4 y dejar explícito el alcance de 2/5. La comprobación funcional de navegador y persistencia pertenece a las pruebas del desarrollador/QA y no se sustituye por esta lectura.

## Revisión final tras correcciones
Se verificó nuevamente la fuente actual. Corregidos los hallazgos materiales: calendario filtra incluidos, admite varias fases y lecciones en una semana; prompt incorpora inventario disponible pendiente, situación/prototipo y explicación del vínculo; los controles antiguos que podrían comprimir decisiones complejas se deshabilitan con orientación hacia la nueva tabla; guía ofrece siguiente decisión contextual y ejemplos; confirmar proyección evita el doble proceso. La documentación explica alcance de IE por saber y obligación de revisar cada IL en el instrumento. Se conserva el fundamento de problema/prototipo abiertos hasta trabajo con estudiantado.

Resultado docente: aprobación pedagógica del alcance implementado para los seis escenarios sétimo, octavo y noveno M1/M2, sin hallazgos materiales pendientes en la lectura final. La aprobación significa correspondencia con los acuerdos de este diseño, no validación institucional del currículo ni sustitución de pruebas con docentes reales.

Verificación funcional: el desarrollador informa 14 pruebas de navegador aprobadas y 0 errores; este agente no las ejecutó personalmente. Sus resultados deben conservarse en el informe QA del equipo.

Mejoras futuras no bloqueantes: enlazar fuentes institucionales exactas en el recorrido, ejemplos adicionales contextualizados por nivel y comprobar comprensión con un docente nuevo. Las fechas del calendario siguen siendo referencias de semana; no se infieren feriados ni fechas individuales de lecciones. Las reservas globales y locales deben verificarse para que el mayor total utilizado no oculte interrupciones distintas.
