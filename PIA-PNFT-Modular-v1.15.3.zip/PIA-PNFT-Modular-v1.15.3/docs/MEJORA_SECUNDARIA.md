# Selección y proyección en secundaria

Esta entrega se construye sobre PIA 1.15.1, preserva su corrección para Abrir/Continuar e incorpora las dos correcciones literales autorizadas de la entrega 1.15.0-ajustes-textuales. No procede de la línea especial 1.17.x.

## Decisiones y persistencia

Inventario y asignación son diferentes. Cada saber conserva módulo, área e indicador literal. Incluir todos mantiene el inventario y nunca asigna todos a las etapas del Proyecto. La selección se ubica en lecciones pedagógicas y/o Etapa I Inicial (Empatizar, Definir, Idear), Etapa II Desarrollo (Prototipar) y Etapa III Final (Probar y Evaluar).

La movilidad cambia el orden, preservando semanas e indicadores. Un vínculo explícito permite mover un grupo; coincidir en semana no crea un vínculo. Se permite integrar la misma área o áreas distintas según la mediación y la acción de cada indicador.

Calendario e inventario editan el mismo estado que el organizador de ruta. Se permiten semanas no consecutivas, múltiples fases por semana y una semana de práctica/profundización sin incorporar otro saber. Se registra la disponibilidad real: dos, una o cero lecciones. Las fechas son referencias calculadas desde el inicio aportado; no equivalen a fechas de las lecciones ni inferencias del calendario oficial. Semana Santa no se fija automáticamente. Las reservas globales de lecciones no lectivas y las registradas en calendario se cuentan mediante el mayor total para evitar duplicación; revise la coincidencia institucionalmente.

Al modificar el calendario se conserva toda asignación y se advierte la reubicación necesaria. No se seleccionan semanas no lectivas para nuevas asignaciones. Al excluir un saber, sus decisiones se conservan en JSON para recuperarlas, pero no aparecen como asignación activa en el calendario.

## Evaluación

El indicador oficial se protege. El indicador de evaluación es elaboración docente y se registra como previsto o contextualizado, acompañado por evidencia, criterio, descriptores, instrumento, puntos máximos y las constancias de elaboración/comunicación previa. No se almacenan estudiantes, resultados ni calificaciones.

Sin situación o prototipo definidos puede prever estos elementos. Revise después de Idear y antes de valorar. La misma acción curricular puede movilizarse en ambas etapas, con evidencia/desempeño diferenciados. La auditoría de repetición textual ayuda a revisar, pero no detecta todas las duplicaciones semánticas ni valida calidad. La persona docente revisa cada correspondencia del instrumento. El catálogo actual de secundaria ofrece un indicador por saber; si una referencia contiene varios, no asuma que un único indicador de evaluación los acredita automáticamente.

Los puntos de los instrumentos se consolidan para el componente final aplicable, sin dividir automáticamente el porcentaje por etapas. Trabajo cotidiano, tareas y Proyecto conservan su finalidad. Prepare y comunique el instrumento antes de valorar. No se impone una cantidad universal de instrumentos, puntos, tema o producto.

## Una proyección

**Confirmar esta proyección** permite generar el prompt semestral sin repetir el organizador. Confirmar conserva pendientes y no certifica viabilidad, ejecución ni RdA alcanzado. El prompt nuevo se incorpora exclusivamente a secundaria y conserva semanas exactas, decisiones, inventario pendiente y evaluación prevista. Si cambia una decisión semántica, la huella informa que un prompt previo puede estar desactualizado; no reemplaza texto docente sin confirmación.

La proyección no escribe automáticamente las semanas del planeamiento. La persona docente elabora luego sus lecciones y estrategias semanales. JSON, autoguardado y portable conservan los nuevos campos; impresión y consulta de la proyección son referencias independientes del Word/PDF oficial. Los registros históricos se conservan y los vínculos curriculares explícitos del Proyecto se recuperan para la nueva tabla.

## Fuentes y accesibilidad

Fundamentos: guía docente de secundaria III Ciclo, Conceptualización del componente Proyecto 2026, Lineamientos técnicos PNFT 2026, Orientaciones generales y apoyos educativos, y reglamento vigente MEP, desarrollados en la guía adjunta. Consulte los documentos oficiales institucionales en caso de actualización o discrepancia. La guía orienta el paso a paso y distingue instrumentos, puntos, porcentaje y momento de evaluación.

Controles por teclado, botones subir/bajar y movimiento a posición evitan depender del arrastre. Inventario y calendario se desplazan horizontalmente en móvil, con inspector vertical, textos y etiquetas completos; estado y guía se conservan. Las orientaciones locales son apoyo, no decisiones curriculares de IA.
