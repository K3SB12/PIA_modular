# Informe de validación — PIA 1.15.0

## Alcance

Esta entrega reorganiza la experiencia de III Ciclo a partir de pruebas realizadas con personas asesoras, incorpora orientación local fundamentada y añade opciones de organización semanal. Los cambios son aditivos: conservan el currículo protegido, el esquema de semanas, las exportaciones y la responsabilidad docente.

## Controles pedagógicos

- El perfil de evaluación debe ser confirmado por la persona docente antes de habilitar el Proyecto.
- La propuesta de IA no modifica una ruta vigente sin validación y selección explícitas.
- Todos los saberes seleccionados deben aparecer en cada propuesta; la integración con el Proyecto exige fase y evidencia coherentes.
- DUA y apoyos autorizados orientan alternativas de mediación sin identificar estudiantes ni modificar silenciosamente el currículo.
- Las actividades puntuales no se presentan como metodologías.
- La orientación local declara fuente, páginas y confianza; una coincidencia débil no se presenta como respuesta cierta.

## Controles técnicos y de accesibilidad

- Persistencia de propuesta elegida, revisión, historial, producto, recursos, evidencia y actividad semanal.
- Navegación mediante teclado, foco visible y controles táctiles.
- Modal de ruta y orientación adaptados a computadora, tableta y celular.
- Tema oscuro conservado en los componentes incorporados.
- Tres salidas HTML byte por byte equivalentes.

## Resultado certificado

La huella SHA-256 definitiva de `index.html`, `dist/web/index.html` y `dist/portable/index.html` es:

`f7a8cfab4096dbdc710765229ec665a0297c4f26f0b1709c450ff1c47b0f00b8`

**Resultado:** 268 pruebas aprobadas, 0 fallos; alcance autorizado e integridad de la entrega aprobados.
