# Revisión UX con asesores — PIA 1.14.4

Esta revisión simplifica el recorrido de III Ciclo sin cambiar el currículo oficial ni sustituir el criterio docente.

## Flujo principal

1. Seleccionar módulo, áreas y saberes.
2. Preparar el diagnóstico pedagógico cuando corresponda.
3. Seleccionar y confirmar el perfil de evaluación aplicable.
4. PIA incorpora el componente Proyecto cuando el perfil confirmado lo incluye.
5. Completar, si se desea, los datos editables del Proyecto. El panel puede plegarse sin perderlos.
6. Abrir el organizador curricular y seguir siete destinos únicos: punto de partida, solicitud a la IA, comparación, agrupación, mapa, calendario y tabla/guardado.

En III Ciclo, si falta confirmar un perfil que incluya Proyecto, PIA detiene la apertura del organizador, explica qué falta y coloca el foco en la confirmación. No existe un segundo interruptor visible para activar el Proyecto.

## Intercambio con IA

La experiencia principal contiene tres acciones:

1. **Preparar y copiar consulta**.
2. **Pegar o importar respuesta**.
3. **Validar y mostrar propuestas**.

Descargas, limpieza y solicitudes de ajuste permanecen disponibles en **Más opciones**. PIA acepta entre dos y cuatro alternativas; muestra una expandida a la vez y no aplica ninguna hasta que la persona docente la seleccione.

## Contrato de propuesta

El esquema `pia-route-options-v4` incorpora de forma aditiva:

- `project.product`: producto o solución posible;
- `project.rationale`: relación pedagógica con los indicadores;
- `project.resources[]`: recursos o alternativas disponibles;
- `project.evidence`: evidencia técnica esperada.

Las respuestas anteriores sin estos campos se conservan por compatibilidad y generan una advertencia de revisión. Al seleccionar una propuesta, el producto aparece como nodo del mapa. Si existe un producto escrito por la persona docente, esa decisión tiene prioridad visual sobre la sugerencia de la IA.

## Reglas que permanecen

- La IA propone; PIA valida y representa; la persona docente decide.
- Ningún porcentaje representa logro, participación o calificación estudiantil.
- Las cinco fases de Pensamiento de Diseño se conservan cuando corresponde Proyecto.
- Las semanas integradas se cuentan una sola vez.
- Plegar paneles o mover nodos no elimina información curricular.
- Las fases semanales solo aparecen en semanas mixtas o integradas mediante Proyecto.

