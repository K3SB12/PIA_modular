# Validación de PIA 1.15.2

Base: PIA-PNFT Modular 1.15.1. Preserva Abrir/Continuar y incorpora las dos correcciones literales previamente autorizadas de PIA1.15.0-ajustes-textuales. La línea especial 1.17.x permanece independiente.

## Resultado

- 290/290 pruebas Node aprobadas: regresiones previas y 17 pruebas nuevas de secundaria.
- 16/16 pruebas de navegador real aprobadas; cero errores JavaScript.
- Seis escenarios de proyección: 7.º, 8.º y 9.º, módulos 1 y 2.
- Revisión pedagógica por un subagente en rol docente: aprobada para los seis escenarios, registrada en REVISION_DOCENTE_SECUNDARIA.md.
- Fuente y alcance autorizado comprobados. Las tres salidas construidas son idénticas.
- No se modifica BASELINE.sha256 ni reference.

## Comprobaciones

Inventarios por escenario: 7M1 18, 7M2 15, 8M1 16, 8M2 12, 9M1 10, 9M2 10 saberes/indicadores. Se verifican texto curricular literal, inclusión sin asignación automática al Proyecto, ubicación en lecciones y fases, mismas fuentes e indicadores propios de Etapa I.

Semanas 2,6,10; receso no lectivo y semana parcial registrados como ejemplos de prueba, sin fijarlos en la aplicación. Se verifica asignación múltiple de fases por semana, rechazo de nuevas asignaciones a recesos, conservación al modificar calendario, movilidad sin cambios de semanas y movimiento de grupos.

IE previstos de Etapa II Desarrollo y Etapa III Final con campos distintos; persistencia de criterio, evidencia, descriptores, puntos, instrumento y constancias de comunicación. Se comprueba el borrado de un IE sin dejar una versión activa anterior y avisos por evidencias repetidas.

Guardado mientras el campo tiene foco, autoguardado, recuperación y recarga, descarga JSON e importación mediante selector real; cambio de módulo y regreso conservan inclusiones/semanas/fases. Portable descargado y reabierto con estado y controles operativos. Se protege texto que incluye cierre de script.

Consulta descargada con semanas exactas y decisiones. Prompt semestral de secundaria confirmado desde la selección, sin repetir el organizador antiguo. Contexto nuevo de cuarto conserva su recorrido y no recibe el bloque de secundaria.

Impresión abre una ventana independiente con contenido y calendario estáticos. Pantalla de escritorio y viewport móvil390px inspeccionados: controles, tabla desplazable y navegación de teclado disponibles. Las capturas y resultados se encuentran en tests/.

## Reproducción y límites

`npm test` verifica fuente, build, alcance, integridad y pruebas Node. `npm run test:browser` requiere Playwright y un navegador instalado; admita PLAYWRIGHT_MODULE y CHROME_EXECUTABLE para su entorno. La prueba registrada utilizó Chrome Headless Shell con Playwright; la inspección móvil corresponde a viewport emulado, no a un dispositivo físico. La revisión docente es del subagente solicitado, no un pilotaje con docentes en institución. Las pruebas confirman comportamiento y preservación de datos; no certifican calidad de una proyección ni aprendizajes del estudiantado.

## Huella

SHA-256 HTML: `c9050efdf2c6844258aabf1e480ebd9895a400509ed044b08f12a6b667cd4b62`
