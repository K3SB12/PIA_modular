# Publicar la revisión correcta de PIA 1.14.4

Esta entrega se reconoce por **PIA Journey · La Ruta del Docente**, su mapa de progresión curricular o “ruta del tesoro”, y por la huella SHA-256 `6242d3a33e3b4f9eae6382c67d6e5fcc22b0422d627889134c37b457e4526db9`.

1. Descargue y extraiga el ZIP de esta entrega.
2. Localice el archivo `index.html` situado en la raíz de la carpeta extraída.
3. En GitHub, confirme en **Settings → Pages** cuál carpeta publica el sitio: raíz `/` o `/docs`.
4. Sustituya el `index.html` de esa ubicación por el archivo recién extraído. No suba un `index.html` conservado en otra carpeta.
5. Confirme el cambio y espere la actualización de GitHub Pages.
6. Abra el sitio con una recarga completa. En **Explorar un ejemplo de planeamiento** debe abrirse **PIA Journey · La Ruta del Docente** y mostrarse la ruta del tesoro.

El ZIP no debe utilizarse como página web. Es un paquete de respaldo que contiene código fuente, pruebas, documentación y tres copias idénticas del HTML ensamblado. Para GitHub Pages basta con publicar el `index.html` extraído en la carpeta configurada.

## Cambios distintivos de esta revisión

- Reflexión docente independiente en cada semana y exportación dentro de esa semana.
- Estructura original de reflexión dentro de cada semana, incluido el apartado separado de observaciones/recomendaciones por nivel.
- PIA Journey y ruta del tesoro restaurados.
- Mejor contraste del tema oscuro en contenido pedagógico y controles.
- Circuito de propuestas IA/JSON, mapa, calendario y exportación selectiva de semanas conservados.
- **239 pruebas aprobadas y 0 fallos**.
