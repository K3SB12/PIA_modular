> Entrega vigente: rediseño de secundaria, 312 pruebas automatizadas y 38 escenarios de navegador aprobados. Consulte INFORME_REDISENIO_SECUNDARIA.md. El informe que sigue documenta la corrección anterior.

# Corrección de referentes curriculares — PIA 1.15.5

## Problema y cambio

El nuevo panel de secundaria mostraba áreas disponibles, pero RdA y marco curricular consultaban las áreas marcadas en el selector anterior oculto. Sin saberes incluidos, no había áreas activas y los contenedores no mostraban los referentes.

Ahora la visualización obtiene las áreas del catálogo oficial para los módulos seleccionados en sétimo, octavo y noveno. Al elegir módulo, se muestran RdA, competencias específicas, perfil de salida y propósito declarado del módulo. No se seleccionan áreas ni saberes automáticamente. Cambiar de módulo actualiza los referentes; sin módulo se muestra una indicación explícita.

La consulta amplia se usa solamente al renderizar los referentes. Los prompts y el organizador continúan utilizando el marco de las áreas incorporadas por la persona docente. No se alteran catálogo oficial, porcentajes MEP, JSON ni decisiones almacenadas. Otros ciclos conservan su consulta por áreas seleccionadas.

## Pruebas

Resultado final: 300/300 pruebas aprobadas, cero fallos; fuente, build, alcance autorizado e integridad aprobados.

Ocho nuevas pruebas ejecutan las funciones de presentación reales con datos oficiales: seis combinaciones de nivel/módulo, falta y cambio de módulo, y conservación de otro ciclo. Comprueban RdA literal, competencias y perfiles visibles sin inclusión, estado sin mutaciones y que el marco usado por prompts no se amplíe.

La suite completa tiene 300 pruebas. npm test comprueba fuente, build, alcance e integridad. La ejecución de las nuevas pruebas es automatizada mediante VM y contenedores simulados; no es una prueba visual en navegador. Persisten los pendientes de navegador y usabilidad documentados en 1.15.4. Esta corrección no autoriza afirmar fidelidad visual completa ni aprobación docente.

## Integridad

SHA-256 de las tres distribuciones HTML idénticas: `dffce4e654c037fdad4aae16505064aeae8d681890434589f85079e45fa5f568`.
