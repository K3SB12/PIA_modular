        // PIA_ENHANCEMENTS_JS_START
        const PIAProjectionCore = (() => {
            const AREA_KEYS = {
                'Apropiación tecnológica y Digital': 'apropiacion',
                'Programación y Algoritmos': 'programacion',
                'Computación física y Robótica': 'robotica',
                'Ciencia de datos e Inteligencia artificial': 'ciencia'
            };
            const PROCEDURAL = [
                ['reconoce','Reconoce patrones'],['abstrae','Abstrae'],['generaliza','Generaliza'],['transfiere','Transfiere'],
                ['modulariza','Modulariza'],['formula','Formula algoritmos'],['remezcla','Remezcla'],['depura','Depura'],
                ['programa','Programa'],['comunica','Comunica'],['colabora','Colabora'],['piensa','Piensa de forma creativa'],
                ['maneja','Maneja las tecnologías de forma ética y segura']
            ];
            const ATTITUDINAL = [['gusto','Gusto por la precisión'],['aprender','Aprender del error'],['flexibilidad','Flexibilidad para manejar problemas'],['tolerancia','Tolerancia a la frustración']];
            function escapeHtml(value) {
                return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
            }
            function conceptId(level, moduleName, area, index) { return [level,moduleName,area,index].map(encodeURIComponent).join('|'); }
            function listConcepts(data, level, modules, areas) {
                const result = [];
                (modules || []).forEach(moduleName => (areas || []).forEach(area => {
                    const items = data?.[level]?.[moduleName]?.[area]?.saberes || [];
                    items.forEach((item, index) => result.push({ id: conceptId(level,moduleName,area,index), level, module: moduleName, area, name: item.nombre, indicators: [...(item.indicadores || [])] }));
                }));
                return result;
            }
            function distribute(concepts, weekCount, preferred = 2, reservedWeeks = 0) {
                const total = Math.max(1, Number(weekCount) || 1);
                const reserved = Math.min(total, Math.max(0, Number(reservedWeeks) || 0));
                const rows = Array.from({length: total}, (_, i) => ({week: i + 1, phase:i<reserved?'diagnóstico':'desarrollo', concepts: [], executed: false}));
                const available = rows.slice(reserved); if (!concepts.length || !available.length) return rows;
                concepts.forEach((concept, index) => available[Math.min(available.length - 1, Math.floor(index / preferred)) % available.length].concepts.push(concept));
                if (concepts.length > available.length * preferred) {
                    available.forEach(row => { row.concepts = []; });
                    concepts.forEach((concept, index) => available[index % available.length].concepts.push(concept));
                }
                return rows;
            }
            function coverage(concepts, assignments) {
                const byArea = {};
                concepts.forEach(c => { byArea[c.area] ||= {selected:new Set(),projected:new Set(),executed:new Set()}; byArea[c.area].selected.add(c.id); });
                assignments.forEach(row => row.concepts.forEach(c => {
                    byArea[c.area] ||= {selected:new Set(),projected:new Set(),executed:new Set()};
                    byArea[c.area].projected.add(c.id); if (row.executed) byArea[c.area].executed.add(c.id);
                }));
                return Object.entries(byArea).map(([area,x]) => ({area, total:x.selected.size, projected:x.projected.size, executed:x.executed.size, projectedPct:x.selected.size ? Math.round(x.projected.size*100/x.selected.size) : 0, executedPct:x.selected.size ? Math.round(x.executed.size*100/x.selected.size) : 0}));
            }
            function defaultEnhancements() {
                return { schemaVersion:6, secondaryPlanning:{order:[],calendarOverrides:{},guideStep:0,view:'inventory'}, identity:{name:'',motto:'',shieldDataUrl:''}, institutional:{codSaber:''}, context:{enabled:false,group:'',resources:'',dua:'',resourceInventory:{devices:'',software:'',materials:'',organization:'',accessibility:'',constraints:''},implementationProfile:'regular',conditions:[],technologyScenario:'sufficient',groupDiagnosis:'pending',supportFramework:'dua',institutionalCoordination:'not-required',duaSupports:[],authorizedSupportNotes:'',vocationalCoordination:false,vocationalSelectionBasis:'',referenceIndicators:[]}, methodology:{purpose:'',route:'',studentRole:'',evidence:'',coordinationMode:'single-design-route',coordinationNotes:'',curricularMethodWeeks:0,feasibilityAcknowledged:false,routePattern:'assisted',routeMode:'guided',routeAssignments:{}}, routeMap:{version:2,confirmed:false,semanticFingerprint:'',view:'map-weeks',selectedId:'',zoom:100,groups:[],connections:[],phaseSchedule:[],positions:{},aiExchange:{responseText:'',payload:null,selectedOptionId:'',selectedOptionSnapshot:null,revisionHistory:[],prompt:'',strategyPrompt:'',updatedAt:''},layers:{procedural:true,attitudinal:true,axes:true,rda:true,evaluation:true},savedAt:''}, status:'draft', calendar:{weeks:22,diagnosisLessons:0,nonTeachingLessons:0,evaluationReserveLessons:0,startDate:'',endDate:'',exceptions:'',blockMinutes:80,effectiveBlockMinutes:0}, diagnostic:{enabled:false,mode:'advisor',purpose:'initial-period',priorSource:'linked',teacherReference:'',manualInstrumentSelection:false,technique:'ai-recommend',instrument:'ai-recommend',instrumentNotes:'',dimensions:{cognitive:true,socioaffective:true,psychomotor:true},experience:'',strengths:'',needs:'',decisions:'',communication:'',linkWeekOne:true,aiResponse:'',aiResponseApproved:false,status:'planned',prompt:'',generatedPrompt:'',savedAt:''}, evaluation:{profileId:'',confirmed:false,guidance:{generatedAt:'',sourceFingerprint:'',suggestions:[]},projectPlanning:{enabled:false,catalogVersion:'',title:'',problem:'',beneficiary:'',expectedSolution:'',plannedWeeks:0,selectedIndicatorIds:[],selectedPhaseIds:[],phaseRecords:{}}}, aiProposal:{originalHtml:'',reviewedHtml:'',status:'empty',sourceFingerprint:'',approvedAt:''}, aiPrompts:{general:'',semester:'',routeStrategies:'',weekly:{}}, aiPromptMeta:{generated:{general:'',semester:'',routeStrategies:'',weekly:{}},savedAt:{general:'',semester:'',routeStrategies:'',weekly:{}},sourceRouteFingerprint:{semester:'',routeStrategies:''}}, aiReview:{generalResponse:'',semesterResponse:'',weeklyResponses:{},reports:{general:[],semester:[],weekly:{}}}, ui:{projectionExpanded:true}, projection:{preschoolTrack:'optimal',modules:[],multiModuleConfirmed:false,areas:[],conceptIds:[],procedural:[],attitudinal:[],assignments:[]}, strategies:[] };
            }
            function migrate(value) {
                const base = defaultEnhancements(); const source = value?.pia || value?.enhancements || {};
                const calendar={...base.calendar,...source.calendar};
                if(source.calendar?.diagnosisLessons===undefined&&source.calendar?.diagnosisWeeks!==undefined) calendar.diagnosisLessons=Math.min(2,Math.max(0,Number(source.calendar.diagnosisWeeks)||0)*2);
                calendar.diagnosisLessons=Math.min(2,Math.max(0,Number(calendar.diagnosisLessons)||0));
                calendar.nonTeachingLessons=Math.max(0,Number(calendar.nonTeachingLessons)||0);
                calendar.evaluationReserveLessons=Math.max(0,Number(calendar.evaluationReserveLessons)||0);
                calendar.effectiveBlockMinutes=Math.min(80,Math.max(0,Number(calendar.effectiveBlockMinutes)||0));
                delete calendar.diagnosisWeeks;
                const oldProject=source.evaluation?.projectPlanning||{};
                const selectedIndicatorIds=Array.isArray(oldProject.selectedIndicatorIds)?oldProject.selectedIndicatorIds:Array.isArray(oldProject.indicatorSnapshots)?oldProject.indicatorSnapshots.map(item=>item.id).filter(Boolean):[];
                const selectedPhaseIds=Array.isArray(oldProject.selectedPhaseIds)?oldProject.selectedPhaseIds:[];
                const phaseRecords=oldProject.phaseRecords&&typeof oldProject.phaseRecords==='object'?JSON.parse(JSON.stringify(oldProject.phaseRecords)):{};
                const weekly=source.aiPrompts?.weekly&&typeof source.aiPrompts.weekly==='object'?source.aiPrompts.weekly:{};
                const references=typeof PIAReferenceCurriculum!=='undefined'?PIAReferenceCurriculum.normalizeList(source.context?.referenceIndicators):Array.isArray(source.context?.referenceIndicators)?source.context.referenceIndicators:[];
                const priorContext=source.context||{},resourceInventory={...base.context.resourceInventory,...(priorContext.resourceInventory||{})},hasPriorContext=Boolean(String(priorContext.group||'').trim()||String(priorContext.resources||'').trim()||String(priorContext.dua||'').trim()||Object.values(resourceInventory).some(value=>String(value||'').trim())||String(priorContext.authorizedSupportNotes||'').trim()||String(priorContext.vocationalSelectionBasis||'').trim()||(priorContext.conditions||[]).length||(priorContext.duaSupports||[]).length||priorContext.vocationalCoordination||(!['', 'dua'].includes(priorContext.supportFramework))||(!['', 'not-required'].includes(priorContext.institutionalCoordination))||(!['', 'regular'].includes(priorContext.implementationProfile))||(!['', 'sufficient'].includes(priorContext.technologyScenario))||(!['', 'pending'].includes(priorContext.groupDiagnosis)));
                const context={...base.context,...priorContext,resourceInventory,enabled:priorContext.enabled===undefined?hasPriorContext:Boolean(priorContext.enabled),conditions:Array.isArray(priorContext.conditions)?priorContext.conditions:[],duaSupports:Array.isArray(priorContext.duaSupports)?priorContext.duaSupports:[],vocationalCoordination:Boolean(priorContext.vocationalCoordination),referenceIndicators:references};
                const meta=source.aiPromptMeta||{};
                const priorDiagnostic=source.diagnostic||{},hasPriorDiagnostic=Boolean(String(priorDiagnostic.prompt||'').trim()||String(priorDiagnostic.experience||'').trim()||String(priorDiagnostic.savedAt||'').trim()||['strengths','needs','decisions','communication'].some(key=>String(priorDiagnostic[key]||'').trim()));
                const legacyManualSelection=Boolean((priorDiagnostic.technique&&priorDiagnostic.technique!=='ai-recommend')||(priorDiagnostic.instrument&&priorDiagnostic.instrument!=='ai-recommend')||String(priorDiagnostic.instrumentNotes||'').trim());
                const diagnostic={...base.diagnostic,...priorDiagnostic,enabled:priorDiagnostic.enabled===undefined?hasPriorDiagnostic:Boolean(priorDiagnostic.enabled),manualInstrumentSelection:priorDiagnostic.manualInstrumentSelection===undefined?legacyManualSelection:Boolean(priorDiagnostic.manualInstrumentSelection),dimensions:{...base.diagnostic.dimensions,...priorDiagnostic.dimensions}};
                const guidance={...base.evaluation.guidance,...source.evaluation?.guidance,suggestions:Array.isArray(source.evaluation?.guidance?.suggestions)?source.evaluation.guidance.suggestions:[]};
                const review=source.aiReview||{};
                const roleSet=new Set(['pending','direct','integrated','prepare','support','pedagogical','continuity']),phaseSet=new Set(['','empathize','define','ideate','prototype','test-evaluate']),rawAssignments=source.methodology?.routeAssignments&&typeof source.methodology.routeAssignments==='object'?source.methodology.routeAssignments:{};
                const routeAssignments=Object.fromEntries(Object.entries(rawAssignments).slice(0,500).map(([id,value])=>{const item=value&&typeof value==='object'?value:{};return [String(id).slice(0,500),{...PIASecondaryPlanningCore.normalizeAssignment(item),role:roleSet.has(item.role)?item.role:'pending',note:String(item.note||'').slice(0,2000),groupId:String(item.groupId||'').slice(0,120),phaseId:PIASecondaryPlanningCore.normalizeAssignment(item).phaseId,weekStart:PIASecondaryPlanningCore.normalizeAssignment(item).weekStart,weekEnd:PIASecondaryPlanningCore.normalizeAssignment(item).weekEnd,color:/^#[0-9a-f]{6}$/i.test(item.color||'')?item.color:'',evidence:String(item.evidence||'').slice(0,1000),evaluationComponent:String(item.evaluationComponent||'').slice(0,120)}];}));
                const methodology={...base.methodology,...source.methodology,routeAssignments};
                const priorMap=source.routeMap&&typeof source.routeMap==='object'?source.routeMap:{},groups=(Array.isArray(priorMap.groups)?priorMap.groups:[]).slice(0,60).map((item,index)=>({id:String(item?.id||`group-${index}`).slice(0,120),title:String(item?.title||`Grupo ${index+1}`).slice(0,120),note:String(item?.note||'').slice(0,1000),color:/^#[0-9a-f]{6}$/i.test(item?.color||'')?item.color:'#28a69a'})),groupIds=new Set(groups.map(item=>item.id));
                const assignmentIds=new Set(Object.keys(routeAssignments)),connections=(Array.isArray(priorMap.connections)?priorMap.connections:[]).slice(0,300).filter(item=>item&&assignmentIds.has(String(item.from))&&assignmentIds.has(String(item.to))&&String(item.from)!==String(item.to)).map((item,index)=>({id:String(item.id||`route-${index}`).slice(0,120),from:String(item.from),to:String(item.to),type:['prepares','supports','evidences','continues','depends-on'].includes(item.type)?item.type:'supports',note:String(item.note||'').slice(0,1000)}));
                Object.values(routeAssignments).forEach(item=>{if(item.groupId&&!groupIds.has(item.groupId))item.groupId='';});
                const phaseSchedule=(Array.isArray(priorMap.phaseSchedule)?priorMap.phaseSchedule:[]).slice(0,10).filter(item=>item&&phaseSet.has(String(item.phaseId||''))&&String(item.phaseId||'')).map(item=>({phaseId:String(item.phaseId),weekStart:Math.max(0,Math.min(60,Number(item.weekStart)||0)),weekEnd:Math.max(0,Math.min(60,Number(item.weekEnd)||Number(item.weekStart)||0)),evidence:String(item.evidence||'').slice(0,1000),linkedConceptIds:(Array.isArray(item.linkedConceptIds)?item.linkedConceptIds:[]).map(String).filter(id=>assignmentIds.has(id)).slice(0,100)}));
                const priorExchange=priorMap.aiExchange&&typeof priorMap.aiExchange==='object'?priorMap.aiExchange:{};
                const selectedOptionSnapshot=priorExchange.selectedOptionSnapshot&&typeof priorExchange.selectedOptionSnapshot==='object'?JSON.parse(JSON.stringify(priorExchange.selectedOptionSnapshot)):null;
                const revisionHistory=(Array.isArray(priorExchange.revisionHistory)?priorExchange.revisionHistory:[]).slice(-10).map(item=>({optionId:String(item?.optionId||'').slice(0,120),title:String(item?.title||'').slice(0,160),savedAt:String(item?.savedAt||'').slice(0,80),option:item?.option&&typeof item.option==='object'?JSON.parse(JSON.stringify(item.option)):null})).filter(item=>item.optionId&&item.option);
                const aiExchange={responseText:String(priorExchange.responseText||'').slice(0,500000),payload:priorExchange.payload&&typeof priorExchange.payload==='object'?priorExchange.payload:null,selectedOptionId:String(priorExchange.selectedOptionId||'').slice(0,120),selectedOptionSnapshot,revisionHistory,prompt:String(priorExchange.prompt||'').slice(0,500000),strategyPrompt:String(priorExchange.strategyPrompt||'').slice(0,500000),updatedAt:String(priorExchange.updatedAt||'').slice(0,80)};
                const rawPositions=priorMap.positions&&typeof priorMap.positions==='object'&&!Array.isArray(priorMap.positions)?priorMap.positions:{};
                const positions=Object.fromEntries(Object.entries(rawPositions).slice(0,800).map(([id,value])=>[String(id).slice(0,500),{x:Math.max(-5000,Math.min(5000,Number(value?.x)||0)),y:Math.max(-5000,Math.min(5000,Number(value?.y)||0))}]).filter(([id])=>id));
                const routeMap={...base.routeMap,...priorMap,version:2,semanticFingerprint:String(priorMap.semanticFingerprint||'').slice(0,80),view:['map-weeks','map','table'].includes(priorMap.view)?priorMap.view:'map-weeks',zoom:Math.max(70,Math.min(140,Number(priorMap.zoom)||100)),selectedId:assignmentIds.has(String(priorMap.selectedId||''))?String(priorMap.selectedId):'',groups,connections,phaseSchedule,positions,aiExchange,layers:{...base.routeMap.layers,...(priorMap.layers||{})}};
                const sourceRouteFingerprint={semester:String(meta.sourceRouteFingerprint?.semester||'').slice(0,80),routeStrategies:String(meta.sourceRouteFingerprint?.routeStrategies||'').slice(0,80)};
                return { ...base, ...source, schemaVersion:6, secondaryPlanning:{...base.secondaryPlanning,...source.secondaryPlanning}, identity:{...base.identity,...source.identity,name:''}, institutional:{...base.institutional,...source.institutional}, context, methodology, routeMap, calendar, diagnostic, evaluation:{...base.evaluation,...source.evaluation,guidance,projectPlanning:{...base.evaluation.projectPlanning,...oldProject,selectedIndicatorIds,selectedPhaseIds,phaseRecords}}, aiProposal:{...base.aiProposal,...source.aiProposal}, aiPrompts:{...base.aiPrompts,...source.aiPrompts,routeStrategies:String(source.aiPrompts?.routeStrategies||'').slice(0,500000),weekly:{...weekly}}, aiPromptMeta:{...base.aiPromptMeta,...meta,generated:{...base.aiPromptMeta.generated,...meta.generated,routeStrategies:String(meta.generated?.routeStrategies||'').slice(0,500000),weekly:{...(meta.generated?.weekly||{})}},savedAt:{...base.aiPromptMeta.savedAt,...meta.savedAt,routeStrategies:String(meta.savedAt?.routeStrategies||'').slice(0,80),weekly:{...(meta.savedAt?.weekly||{})}},sourceRouteFingerprint}, aiReview:{...base.aiReview,...review,weeklyResponses:{...(review.weeklyResponses||{})},reports:{...base.aiReview.reports,...review.reports,weekly:{...(review.reports?.weekly||{})}}}, ui:{...base.ui,...source.ui}, projection:{...base.projection,...source.projection}, strategies:Array.isArray(source.strategies)?source.strategies:[] };
            }
            return {AREA_KEYS,PROCEDURAL,ATTITUDINAL,escapeHtml,conceptId,listConcepts,distribute,coverage,defaultEnhancements,migrate};
        })();
        // PIA_SECONDARY_PLANNING_CORE_START
        const PIASecondaryPlanningCore = (() => {
            // Descriptores literales de la Guía docente FT–Secundaria III Ciclo, pp. 52–54.
            const descriptors=Object.freeze({
"reconoce":"Predice a partir de las regularidades, similitudes o características comunes de un conjunto de datos o situaciones, patrones que pueda aplicar en la solución a un problema o situación.",
"abstrae":"Concluye cuáles son las características relevantes que debe considerar y cuáles debe omitir, al resolver un problema o situación.",
"generaliza":"Generaliza las funcionalidades o estructuras generales de un elemento que pueda aprovechar en otros contextos al resolver un problema o situación.",
"transfiere":"Transfiere conocimientos, habilidades y estrategias aprendidas previamente en un contexto específico, a situaciones diferentes y nuevas al resolver un problema o situación.",
"modulariza":"Resuelve un problema por partes menos complejas, sin perder de vista el todo que las origina, al resolver un problema o situación.",
"formula":"Formula algoritmos por medio de una secuencia ordenada y detallada de pasos para resolver un problema o situación.",
"remezcla":"Combina diferentes ideas, técnicas o soluciones existentes, con la autorización correspondiente, de manera innovadora y creativa para resolver un problema o situación.",
"depura":"Valida el funcionamiento de los algoritmos en busca de errores para corregirlos al resolver un problema o situación.",
"programa":"Programa mediante un entorno o IDE de programación para resolver un problema o situación.",
"comunica":"Comunica ideas o soluciones a problemas o situaciones de manera creativa, coherente y comprensible, compartiendo conocimientos con otros al resolver un problema o situación.",
"colabora":"Demuestra un trato constructivo y respetuoso para resolver un problema o situación específica, al trabajar con otros y así apoyar su aprendizaje y contribuir al de los demás al resolver un problema o situación.",
"piensa":"Desarrolla soluciones ingeniosas, innovadoras, originales con enfoques no convencionales, al resolver un problema o situación.",
"maneja":"Aplica de manera consciente fundamentos de ética y seguridad digital al utilizar herramientas y recursos tecnológicos al resolver un problema o situación.",
"gusto":"Demuestra ante los procesos de aprendizaje un comportamiento hacia la búsqueda de la exactitud, al ser minucioso con los detalles.",
"aprender":"Demuestra ante los errores un comportamiento que le permita ganar experiencia a partir de lecciones aprendidas producto de los errores, convirtiendo los desaciertos en oportunidades de aprendizaje.",
"flexibilidad":"Demuestra un comportamiento hacia la adaptabilidad, flexibilidad y resiliencia ante los desafíos o situaciones imprevistas producto del entorno, la interacción con otros, o bien, con los recursos.",
"tolerancia":"Demuestra ante los desafíos, un comportamiento hacia la búsqueda de la autoconfianza, motivación, autocontrol, paciencia y persistencia."
});
            const phases=['empathize','define','ideate','prototype','test-evaluate'];
            const phaseLabels={empathize:'Etapa I Inicial — Empatizar',define:'Etapa I Inicial — Definir',ideate:'Etapa I Inicial — Idear',prototype:'Etapa II Desarrollo — Prototipar','test-evaluate':'Etapa III Final — Probar y Evaluar'};
            const text=value=>String(value??'').slice(0,6000);
            const numbers=value=>[...new Set((Array.isArray(value)?value:[]).map(Number).filter(n=>Number.isInteger(n)&&n>0&&n<=60))].sort((a,b)=>a-b);
            function evaluation(value={}){return {indicator:text(value.indicator),evidence:text(value.evidence),criterion:text(value.criterion),descriptors:text(value.descriptors),points:text(value.points),instrument:text(value.instrument),prepared:Boolean(value.prepared),communicated:Boolean(value.communicated),status:value.status==='contextualized'?'contextualized':'provisional'};}
            function normalizeAssignment(value={}){
                const legacyWeeks=value.weekStart?Array.from({length:Math.max(0,Math.min(60,(Number(value.weekEnd)||Number(value.weekStart))-Number(value.weekStart)+1))},(_,i)=>Number(value.weekStart)+i):[];
                const weeks=numbers(Array.isArray(value.weeks)?value.weeks:legacyWeeks),phaseIds=[...new Set((Array.isArray(value.phaseIds)?value.phaseIds:value.phaseId?[value.phaseId]:[]).filter(id=>phases.includes(id)))],old=value.secondary||{};
                return {...value,weeks,phaseIds,weekStart:weeks[0]||0,weekEnd:weeks.at(-1)||0,phaseId:phaseIds[0]||'',secondary:{lessons:old.lessons===undefined?['pedagogical','prepare','support','continuity','integrated'].includes(value.role):Boolean(old.lessons),mediacion:text(old.mediacion),procedural:(Array.isArray(old.procedural)?old.procedural:[]).map(text),attitudinal:(Array.isArray(old.attitudinal)?old.attitudinal:[]).map(text),axes:(Array.isArray(old.axes)?old.axes:[]).map(text),evaluations:{prototype:evaluation(old.evaluations?.prototype),'test-evaluate':evaluation(old.evaluations?.['test-evaluate'])}}};
            }
            function parseWeeks(input,max=60,overrides={}){
                const raw=String(input??'').trim();if(!raw)return [];
                const result=[];for(const token of raw.split(/[,;]/)){const match=token.trim().match(/^(\d+)(?:\s*[-–—]\s*(\d+))?$/);if(!match)throw Error('Use 3, 7–9 o 2, 6, 10.');const start=Number(match[1]),end=Number(match[2]||match[1]);if(start<1||end<start||end>max)throw Error(`Seleccione semanas entre 1 y ${max}; revise el rango.`);for(let week=start;week<=end;week++){if(Number(overrides[week]?.lessons)===0)throw Error(`La semana ${week} es no lectiva. Conserve la asignación previa para revisarla o elija otra semana.`);result.push(week);}}
                return numbers(result);
            }
            function calendar(count,startDate='',overrides={}){const valid=/^\d{4}-\d{2}-\d{2}$/.test(startDate)&&Number.isFinite(Date.parse(startDate+'T12:00:00Z'));return Array.from({length:Math.max(1,Math.min(60,Number(count)||1))},(_,i)=>{const week=i+1,entry=overrides[week]||{};let date='';if(valid){const d=new Date(startDate+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+7*i);date=d.toISOString().slice(0,10);}return {week,date,lessons:entry.lessons===undefined?2:Math.max(0,Math.min(2,Number(entry.lessons)||0)),reason:text(entry.reason),phaseId:phases.includes(entry.phaseId)?entry.phaseId:'',phaseIds:[...new Set((Array.isArray(entry.phaseIds)?entry.phaseIds:entry.phaseId?[entry.phaseId]:[]).filter(p=>phases.includes(p)))],pedagogical:entry.pedagogical===undefined?true:Boolean(entry.pedagogical),activity:text(entry.activity)};});}
            function move(order,id,direction,assignments={}){const result=[...order],index=result.indexOf(id);if(index<0)return result;const group=assignments[id]?.groupId;const block=group?result.filter(key=>assignments[key]?.groupId===group):[id],rest=result.filter(key=>!block.includes(key)),anchor=result.findIndex(key=>block.includes(key)),position=Math.min(rest.length,Math.max(0,direction==='up'?anchor-1:direction==='down'?anchor+1:Number(direction)-1));rest.splice(position,0,...block);return rest;}
            function audit(concepts,assignments,max,overrides={}){const warnings=[],evidences=new Map();for(const c of concepts){const a=normalizeAssignment(assignments[c.id]);if(!a.weeks.length)warnings.push(`${c.name}: semanas pendientes.`);if(!a.secondary.lessons&&!a.phaseIds.length)warnings.push(`${c.name}: ubicación pendiente; no se retiró del inventario.`);for(const week of a.weeks)if(week>max||Number(overrides[week]?.lessons)===0)warnings.push(`${c.name}: revise la semana ${week}; calendario modificado o no lectivo. La asignación se conserva.`);for(const phase of ['prototype','test-evaluate']){if(!a.phaseIds.includes(phase))continue;const e=a.secondary.evaluations[phase];if(e.status==='provisional')warnings.push(`${c.name}, ${phaseLabels[phase]}: evaluación prevista; contextualice después de Idear y antes de valorar.`);if(e.status==='contextualized'&&(!e.indicator||!e.evidence||!e.criterion||!e.descriptors||!e.instrument||!e.prepared||!e.communicated))warnings.push(`${c.name}, ${phaseLabels[phase]}: complete y comunique el instrumento antes de valorar.`);if(e.points&&(!Number.isFinite(Number(e.points))||Number(e.points)<=0))warnings.push(`${c.name}: revise los puntos previstos; use una cantidad positiva.`);const key=e.evidence.trim().toLocaleLowerCase();if(key){if(evidences.has(key))warnings.push(`${c.name}: evidencia repetida; compruebe desempeños distintos y evite doble valoración.`);evidences.set(key,true);}}}return [...new Set(warnings)];}
            // Revisión estructural: nunca certifica pertinencia pedagógica ni logro del RdA.
            function distributionStatus(concepts,assignments,max,overrides={}) {
                const pending=[];
                if(!concepts.length)pending.push('Incluya al menos un saber.');
                for(const c of concepts){
                    const a=normalizeAssignment(assignments[c.id]);
                    if(!a.weeks.length)pending.push(`${c.name}: semanas pendientes.`);
                    if(!a.secondary.lessons&&!a.phaseIds.length)pending.push(`${c.name}: ubicación pendiente.`);
                    for(const week of a.weeks)if(week>max||Number(overrides[week]?.lessons)===0)pending.push(`${c.name}: revise la semana ${week}.`);
                }
                return {complete:pending.length===0,pending:[...new Set(pending)]};
            }
            function validateOrganization(payload,concepts,max,overrides,fingerprint,projectEnabled=false){
                if(payload?.schema!=='pia-secondary-organization-v1'||payload.fingerprint!==fingerprint)throw Error('El JSON o su huella no corresponden al módulo, calendario y selección vigentes. Prepare una consulta nueva.');
                if(!Array.isArray(payload.options)||payload.options.length<1||payload.options.length>3)throw Error('Incluya de una a tres propuestas.');
                const byId=new Map(concepts.map(c=>[c.id,c])),optionIds=new Set();
                return payload.options.map(option=>{
                    const id=text(option?.id);if(!id||optionIds.has(id))throw Error('Cada propuesta debe tener un ID único.');optionIds.add(id);
                    if(!Array.isArray(option.assignments)||option.assignments.length!==concepts.length)throw Error('Cada propuesta debe contemplar todos los saberes del inventario, incluidos los pendientes.');
                    const groupIds=new Set(),groups=(Array.isArray(option.groups)?option.groups:[]).slice(0,100).map(g=>{if(!g?.id||groupIds.has(String(g.id)))throw Error('Los vínculos requieren IDs únicos.');groupIds.add(String(g.id));return {id:text(g.id),title:text(g.title),note:text(g.note)};});
                    const used=new Set(),allPhases=new Set();
                    const assignments=option.assignments.map(item=>{
                        if(!byId.has(item?.conceptId)||used.has(item.conceptId))throw Error('Un saber está repetido o no pertenece al inventario vigente.');used.add(item.conceptId);
                        if(typeof item.included!=='boolean')throw Error('Indique included:true o included:false para cada saber.');
                        const weeks=parseWeeks((Array.isArray(item.weeks)?item.weeks:[]).join(','),max,overrides);
                        if(!Array.isArray(item.phaseIds)||item.phaseIds.some(p=>!phases.includes(p)))throw Error('La propuesta incluye una fase desconocida.');
                        const phaseIds=[...new Set(item.phaseIds)];phaseIds.forEach(p=>allPhases.add(p));
                        if(!projectEnabled&&phaseIds.length)throw Error('El perfil de evaluación debe habilitar Proyecto antes de proponer sus fases.');
                        if(item.groupId&&!groupIds.has(item.groupId))throw Error('La propuesta incluye un vínculo inexistente.');
                        if(item.officialIndicators&&JSON.stringify(item.officialIndicators)!==JSON.stringify(byId.get(item.conceptId).indicators))throw Error('La propuesta modificó un indicador oficial.');
                        if(!item.included&&(weeks.length||phaseIds.length))throw Error('Un saber no incluido debe conservar semanas y fases vacías.');
                        return {conceptId:item.conceptId,included:item.included,weeks,phaseIds,groupId:text(item.groupId),evidence:text(item.evidence),evaluationComponent:['Trabajo cotidiano','Tareas','Proyecto','Por definir',''].includes(item.evaluationComponent)?item.evaluationComponent:'Por definir',secondary:{lessons:Boolean(item.secondary?.lessons),mediacion:text(item.secondary?.mediacion)}};
                    });
                    const calendarIds=new Set(),calendar=(Array.isArray(option.calendar)?option.calendar:[]).slice(0,60).map(w=>{const week=Number(w.week);if(!Number.isInteger(week)||week<1||week>max||Number(overrides[week]?.lessons)===0||calendarIds.has(week))throw Error('Revise las semanas del calendario propuesto; no pueden estar repetidas, fuera del periodo o sin lecciones.');calendarIds.add(week);if(!Array.isArray(w.phaseIds)||w.phaseIds.some(p=>!phases.includes(p)))throw Error('El calendario incluye una fase desconocida.');const phaseIds=[...new Set(w.phaseIds)];phaseIds.forEach(p=>allPhases.add(p));if(!projectEnabled&&phaseIds.length)throw Error('Proyecto no está habilitado por el perfil.');return {week,phaseIds,activity:text(w.activity)};});
                    if(projectEnabled&&phases.some(p=>!allPhases.has(p)))throw Error('La propuesta debe contemplar las cinco fases de las tres etapas del Proyecto.');
                    return {id,title:text(option.title)||id,reason:text(option.reason),groups,assignments,calendar};
                });
            }
            return {phases,phaseLabels,normalizeAssignment,parseWeeks,calendar,move,audit,evaluation,distributionStatus,validateOrganization,descriptors};
        })();
        // PIA_SECONDARY_PLANNING_CORE_END
