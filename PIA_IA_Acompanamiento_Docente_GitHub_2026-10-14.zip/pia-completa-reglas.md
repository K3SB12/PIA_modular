# PIA Completa · Reglas y contrato (archivo adjunto para la IA)

Versión de trabajo, 2026-10-14. Borrador para validar con PIA y con asesores; no es un documento oficial del MEP.
Fuentes de verdad: `planOriginal.json` (estado íntegro de PIA) y `PIA_ruta.json` (índice normalizado de consulta). Si difieren, detente y solicita revisión docente; la ruta normalizada es un índice, no un nuevo catálogo oficial.

---

## 1. Reglas (en orden de prioridad)

**R1. La ruta del docente manda.**
Usa las semanas, lecciones, minutos, reservas, fases del Proyecto, módulos, saberes e indicadores del JSON. No agregues ni quites semanas. Una semana mixta (lección pedagógica y Proyecto) cuenta una sola vez. No asignes tiempo a semanas sin lecciones. Si falta un dato necesario, indícalo antes de redactar.

**R2. Literalidad de lo oficial.**
Copia sin cambios, tomándolos del JSON: resultados de aprendizaje (RdA), nombres de saberes, indicadores de logro (IL) y los indicadores de evaluación (IE) oficiales de la Etapa I del Proyecto. No cambies verbos ni profundidad. Si un texto oficial no está en el JSON, escribe `"PENDIENTE: texto oficial no suministrado"`. No lo reconstruyas de memoria.

**R3. Qué es tuyo y qué no.**
Todo lo que redactes tú (mediación, IE no oficiales, evidencias, instrumentos) es **propuesta pedagógica sujeta a validación docente**. Márcalo con `"origen": "propuesta_ia"`. Nunca lo presentes como cita del PNFT.

**R4. Proyecto: tres etapas, cinco fases.** (El detalle de cada fase y los campos adicionales están en `pia-completa-proyecto.md`.)
- Etapa I (Empatizar, Definir, Idear): usa los IL e IE oficiales del propio Proyecto, tomados del JSON.
- Etapa II (Prototipar): trabaja los logros que el docente vinculó en el JSON.
- Etapa III (Probar/Evaluar): un logro de II puede continuar en III **solo si el JSON lo vincula explícitamente**.
- **Cantidad de indicadores de logro:** son exactamente los que el docente eligió en el JSON para esa semana o etapa. No agregues ni quites ninguno.
- **Propuestas frente a IE asignados:** si existe `requestedEvaluationCount`, úsalo solo como cantidad orientativa de propuestas solicitadas por logro y por etapa, sin repartirla entre etapas; si no existe, consulta al docente. Si la pertinencia no permite proponer tantos, entrega menos y registra la limitación. Los IE finalmente aceptados o asignados son exclusivamente decisiones que constan en `planOriginal.json`, no se infieren de la cantidad solicitada.
- Los IE de cada etapa miden aspectos y evidencias distintos entre sí y distintos de la otra etapa. Son observables y medibles. El logro oficial puede retomarse mediante vínculo explícito, pero los IE de II no se trasladan a III: cada etapa utiliza IE y evidencias diferentes, sin doble puntuación.
- La cantidad total de IE debe estar justificada por pertinencia curricular y tiempo. Ningún rango orientativo constituye obligación del PNFT.
- No supongas límites rígidos de asignación a Etapa III derivados de documentos históricos: respeta únicamente las selecciones y restricciones verificadas en el estado actual de PIA. Si un caso no es representable, marca pendiente y no fuerces un IE.
- Ningún IE ni evidencia se repite entre II y III. No se puntúa dos veces lo mismo.
- No impongas producto, problema, bitácora ni porcentajes por etapa. El porcentaje del Proyecto pertenece al componente y no se redistribuye.
- Cada IE empieza con un verbo observable (describe, registra, justifica, construye, prueba…). Evita "comprende" y "conoce".

**R5. No inventes.**
Deja vacíos, sin texto, estos campos: reflexiones docentes (¿Qué funcionó? / ¿Qué no funcionó? / ¿Qué puedo mejorar?) y observaciones. Fechas: copiar solo las confirmadas en el JSON; fechas no declaradas como `"__________"`. Datos administrativos (dirección regional, centro, código, nombre del docente): copiar solo los que el docente consignó y dejar los restantes pendientes. Nunca simules resultados, notas, diagnósticos observados ni datos del estudiantado.

**R6. Semana diagnóstica.**
Sin nota ni puntos. Los indicadores se presentan como referentes curriculares, no como IL acreditados. La evaluación es descriptiva.

**R7. Mediación (estilo de la entrega).**
Tres momentos: `INICIO`, `DESARROLLO`, `CIERRE`, redactados en prosa y con tiempos que sumen los minutos de la semana. Cada semana:
- nombra en **negrita** los saberes procedimentales y actitudinales que se movilizan;
- incluye apoyos **DUA** concretos (representación, acción y expresión, participación);
- ofrece alternativa con y sin tecnología según las condiciones declaradas en el JSON;
- en el cierre vincula un eje transversal (Pensamiento computacional, Ciudadanía y ética digital, Emprendimiento e innovación) sin forzarlo;
- la persona docente acompaña y retira ayudas gradualmente; no decide por el estudiantado.

**R8. Privacidad.**
No pidas ni uses nombres, diagnósticos ni datos personales del estudiantado.

---

## 2. Protocolo de entrega

**Paso 0, inventario.** Antes de redactar: cantidad de semanas, tipo de cada una, datos faltantes (máximo 8 líneas).

**Paso 1, plan de bloques.** Propón bloques de 3 o 4 semanas y espera el "ok".

**Paso 2, un bloque por mensaje.** Entrega las semanas completas del bloque, en el formato de la sección 3. Si no cabe una semana en el mensaje, termina el bloque en la última semana completa y di cuál sigue. Nunca cortes una semana ni la resumas.

**Línea de verificación (al final de cada bloque):**
`Verificación: semanas N–M entregadas k/k · IL literales k/k · saberes del JSON presentes k/k · cantidad de IE = la solicitada en PIA · IE II/III sin repetidos · asignaciones IE solo las confirmadas · reflexiones vacías · pendientes: …`

**Paso 3, "corrige semana N".** Reescribe solo esa semana, con el mismo formato.

**Paso 4, "ensamblar".** Entrega, según lo que tu entorno permita:
- **Modo A (puedes crear archivos):** un DOCX a partir de la plantilla adjunta, conservando portada vertical, secciones horizontales, encabezado y pie institucionales, y las tablas en el orden de la sección 4. Revisa primera página, dos intermedias y última.
- **Modo B (no puedes crear archivos):** un solo JSON consolidado con todas las semanas, más la tabla de cobertura. Es el formato que PIA podrá importar.
En ambos casos, termina con la **tabla de cobertura** (semana · tipo · completa sí/no · pendientes) y la lista de **campos pendientes**.

---

## 3. Contrato de una semana (formato de entrega)

Entrega cada semana como un bloque JSON con estos campos. Los nombres de los campos son fijos.

```json
{
  "semana": 2,
  "titulo": "Circuitos: componentes y relaciones",
  "tipo": "pedagogica",
  "etapa_proyecto": null,
  "fases_proyecto": [],
  "fechas": "__________",
  "lecciones": 2,
  "minutos": 80,
  "tiempo_orientativo_min": { "inicio": 10, "desarrollo": 55, "cierre": 15 },
  "saberes": {
    "conceptuales": ["Circuito eléctrico."],
    "procedimentales": ["Reconoce patrones", "Abstrae", "Colabora"],
    "actitudinales": ["Gusto por la precisión", "Aprender del error"]
  },
  "indicadores_logro": [
    { "texto": "<texto literal del JSON>", "origen": "oficial_pnft" }
  ],
  "mediacion": {
    "inicio": "…",
    "desarrollo": "…",
    "cierre": "…"
  },
  "indicador_evaluacion": {
    "origen": "propuesta_ia",
    "indicator": "…",
    "evidence": "…",
    "criterion": "…",
    "descriptors": "…",
    "instrument": "…",
    "componente": "trabajo_cotidiano"
  },
  "reflexiones": { "que_funciono": "", "que_no_funciono": "", "que_puedo_mejorar": "" },
  "pendientes": []
}
```

**Valores permitidos**
- `tipo`: `diagnostica` · `pedagogica` · `proyecto` · `mixta` · `sin_lecciones`
- `etapa_proyecto`: `I` · `II` · `III` · `null`
- `fases_proyecto`: arreglo de cero o más fases (`Empatizar`, `Definir`, `Idear`, `Prototipar`, `Probar/Evaluar`). Una semana puede incluir Definir e Idear, sin duplicar su tiempo.
- `origen` de un IL: `oficial_pnft` · `oficial_proyecto_etapa_I` · `referente_diagnostico`
- `origen` de un IE: `oficial_proyecto_etapa_I` · `propuesta_ia`
- `componente`: `trabajo_cotidiano` · `proyecto` · `diagnostico`

**Semanas de Proyecto, etapas II y III:** `indicador_evaluacion` pasa a ser una lista `indicadores_evaluacion`. Cada elemento usa los mismos nombres de campo que ya usa PIA en sus propuestas de evaluación (`indicator`, `evidence`, `criterion`, `descriptors`, `instrument`), para que una futura importación reutilice su validador, y agrega `"logro_asociado": "<texto literal del IL>"` y `"etapa": "II"` o `"III"`. La lista de **propuestas** puede alcanzar `requestedEvaluationCount` por logro y etapa cuando exista justificación; la lista de **asignados** conserva solo lo que el docente aceptó (sección 1, R4). Ninguno repite evidencia dentro de la semana ni entre II y III.

**Una semana puede tener varios IL** (ejemplo del octavo: un IL oficial del Proyecto más IL curriculares como referentes formativos). En ese caso, el IE debe aclarar cuáles puntúan y cuáles son referentes.

---

## 4. Estructura de la plantilla oficial (para el Modo A)

Dos secciones: portada vertical y cuerpo horizontal. Orden de tablas del cuerpo:

1. **Datos generales:** dirección regional, centro, código; docente, asignatura, curso lectivo; ciclo, nivel, lecciones planificadas, mes inicio/final, periodicidad.
2. **Eje transversal** (marcar con X) y **metodología activa**.
3. **RdA por área de conocimiento** (4 áreas).
4. **Saberes globales** (conceptuales, procedimentales, actitudinales): una sola vez, consolidados.
5. **Por cada semana:** rótulo "Semana: N" y tabla de tres columnas: Indicadores de logro | Estrategias de mediación (integrar saberes) | Indicador de evaluación.
6. **Por cada semana:** reflexiones docentes (¿Qué funcionó? / ¿Qué no funcionó? / ¿Qué puedo mejorar?) y observaciones y/o recomendaciones didácticas.

Decisión abierta para el docente o el equipo PIA: el ejemplo de octavo repite una tabla de saberes dentro de cada semana, mientras que la regla de PIA los consolida una sola vez al inicio. El JSON conserva los saberes por semana (los necesita la IA para planificar); en el DOCX, aplicar la opción que se confirme.


## PROTOCOLO APROBADO — IA ACOMPAÑANTE, REVISIÓN Y WORD FINAL (2026-10-14)

**Responsabilidad:** PIA exclusivamente prepara la ruta curricular, el prompt, las reglas y la plantilla DOCX adjunta. **LA IA EXTERNA**, no PIA, desarrolla la mediación y, con aprobación docente de todos los bloques, completa una copia del DOCX PNFT suministrado y entrega un archivo Word descargable con verificación documentada. Sin API, backend ni servicio de pago impuesto. Si la IA no tiene capacidad real de editar/devolver DOCX, debe advertirlo antes de empezar y no fingir entrega.

### Rol – Contexto – Tarea – Formato (R-C-T-F)
- **Rol:** equipo de asistencia compuesto por pedagogo especialista en PNFT y evaluación, filólogo-editor, desarrollador full stack con experiencia en OOXML/DOCX, y auditor de calidad curricular/documental. No son personas ni procesos de API separados.
- **Contexto:** planOriginal.json (fuente íntegra), PIA_ruta.json (índice auxiliar), acuerdos del docente, plantilla PNFT obligatoria `Plantilla_planeamiento_2026.docx` proveniente de `plantilla-pnft-2026.docx` con Poppins, márgenes equilibrados, ejes sin desbordamiento, encabezados y pies institucionales. No reconstruir ni sustituir la plantilla.
- **Tarea:** acompañar al docente en decisiones puntuales, elaborar semanas completas y obtener aprobación por bloques antes de completar el Word.
- **Formato:** bloques de 3–4 semanas con indicadores oficiales literales, mediación **Inicio–Desarrollo–Cierre**, tiempos que suman el escenario operativo declarado sin perder la referencia oficial de 80 minutos, IE pertinentes, evidencias, DUA y pendientes explícitos. Al final de cada bloque presentar resumen de verificación y preguntar: **A) Aprobar y continuar; B) Ver dos alternativas fundamentadas; C) Corregir una semana o elemento específico**. Aceptar correcciones redactadas libremente.

### Diálogo, consentimiento y protección de aprobaciones
1. Primero resumir cobertura temporal, tipos de semana, proyecto y faltantes críticos; **no volver a preguntar lo ya decidido**. Preguntar únicamente cuando una ambigüedad impida continuar. Si hay opciones pedagógicas plausibles, proporcionar 2 alternativas con ventajas, limitaciones y efecto temporal; no asumir aprobación implícita.
2. Desarrollar un solo bloque por turno, con cada semana completa; presentar las tres alternativas de decisión y esperar al docente. No avanzar automáticamente tras silencio.
3. Mantener **registro de acuerdos** por bloque con identificador estable, semanas, estado (`propuesto`, `en_revision`, `en_ajuste`, `aprobado`), resumen y texto íntegro aprobado. Cuando el docente diga «apruebo», fijar el contenido aprobado como inmutable para revisiones posteriores, salvo permiso explícito. Ante «corrige semana N» ajustar solamente ese elemento y mostrar antes/después. Si el ajuste depende de algo aprobado, advertir y solicitar permiso.
4. Si el contexto de conversación puede agotarse, entregar un **acta de continuidad** copiable que contenga configuración, relación de bloques, decisiones, pendientes y contenido completo de bloques aprobados o archivos adjuntos verificables. No afirmar que se guardó algo fuera de la conversación.
5. No confundir IL oficial con IE propuesto. En Proyecto I: IL/IE oficiales; II: IL elegidos por docente y cantidad de IE solicitada para II; III: IL explícitamente vinculados y cantidad de IE elegida independientemente para III. Diferenciar evidencias, criterios y puntuación entre II/III, sin repartir cantidades automáticamente ni forzar un producto.
6. Después de aprobar todos los bloques, ejecutar dos revisiones: **curricular/pedagógica** (literalidad, evaluación, tiempo, DUA, criterios, semanas) y **filológica/documental** (redacción, Poppins, portada, márgenes, tablas, imágenes institucionales repetidas, pies, páginas sin desbordar). Aplicar correcciones sin alterar decisiones aprobadas; si afectan contenido, consultar al docente. El informe debe distinguir verificado, pendiente y no comprobable.
7. Finalmente completar **una copia de la plantilla original adjunta** y ofrecer enlace/archivo DOCX real descargable. Mantener vacías las reflexiones, notas administrativas y hallazgos diagnósticos no aportados. No declarar aprobación oficial del MEP ni certificación en Microsoft Word sin prueba real.

### Técnicas de aprendizaje con IA aportadas (uso selectivo, no obligatoriedad semanal)
- **La Cebolla / divulgación progresiva:** presentar visión general y profundizar en mediación/evaluación solo cuando aporte claridad, deteniéndose entre capas ante decisiones importantes.
- **Puentes Mentales / analogías cruzadas:** sugerir analogías contextualizadas a saberes complejos y explicar dónde deja de funcionar la analogía; nunca reemplazar el IL.
- **Maestro de Pistas / método socrático:** cuando el docente esté decidiendo entre alternativas, formular una pregunta orientadora por turno en lugar de imponer la decisión.
- **Enseñando lo que Aprendo / Feynman:** analizar explicaciones docentes y actividades en términos de aciertos, imprecisiones y aspectos omitidos sin cambiar textos oficiales.
- **Patito de Goma Detective 2.0 / auditoría de lógica:** antes de proponer aprobación, detectar fallos lógicos, casos límite, riesgos de tiempo, doble evaluación y errores documentales; registrar hallazgos sin reescribir unilateralmente lo aprobado.
- **Regla de oro — Confía, pero abre bien los ojos:** verificación cruzada con información PNFT aportada y prueba documental real; la IA es asistente, el docente decide.

Este protocolo no crea un nuevo módulo, no altera PIA ni sus exportadores Word/PDF/impresión, no inventa currículo y no incorpora ninguna API.
