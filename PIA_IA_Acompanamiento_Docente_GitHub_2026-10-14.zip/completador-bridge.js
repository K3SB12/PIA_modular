/* PIA Completa — módulo aislado de preparación de paquetes; no altera estado PIA. */
(function(root){'use strict';
  const VERSION='pia-ruta-v1.0';
  const phases=new Map([['empathize','Empatizar'],['define','Definir'],['ideate','Idear'],['prototype','Prototipar'],['test','Probar/Evaluar'],['evaluate','Probar/Evaluar'],['test-evaluate','Probar/Evaluar']]);
  const arr=v=>Array.isArray(v)?v:[];
  const txt=v=>typeof v==='string'?v.trim():'';
  const val=v=>v===undefined?null:v;
  function assertPlan(plan){if(!plan||typeof plan!=='object'||Array.isArray(plan)||!Array.isArray(plan.semanas))throw new Error('El archivo no contiene un planeamiento PIA con la lista semanas.');if(plan.semanas.length>120)throw new Error('La ruta supera el límite preventivo de 120 semanas.');return plan;}
  function normalize(plan){
    assertPlan(plan);
    const pia=plan.pia&&typeof plan.pia==='object'?plan.pia:{};
    const general=plan.informacionGeneral||{};
    const warnings=[];
    if(!plan.pia) warnings.push('El JSON no incluye estado pia: la distribución avanzada del Proyecto y el calendario podrían faltar. Descargue el JSON completo desde PIA actualizado.');
    const weeks=plan.semanas.map((w,i)=>{
      if(!w||typeof w!=='object') {warnings.push(`Semana ${i+1}: registro ausente.`);w={};}
      const project=w.project&&typeof w.project==='object'?w.project:{};
      const assigned=[];
      const identifiers=[project.phaseId,...arr(project.phaseIds),...arr(project.phases).map(p=>typeof p==='string'?p:p?.phaseId)].filter(Boolean);
      for(const id of identifiers){const phase=phases.get(id)||id;if(!assigned.includes(phase))assigned.push(phase);}
      for(const [key,record] of Object.entries(project.records||{})){
        const meaningful=record&&typeof record==='object'&&(arr(record.achievementIndicators).length||arr(record.evaluationIndicators).length||arr(record.selectedIndicators).length);
        if(meaningful){const phase=phases.get(key)||key;if(!assigned.includes(phase))assigned.push(phase);}
      }
      const lessonNum=Number(w.lecciones);
      const isZero=Number.isFinite(lessonNum)&&lessonNum===0;
      const projectActive=Boolean(assigned.length)||project.mode==='mixed'||project.mode==='integrated';
      const pedagogic=project.mode==='mixed'||(!projectActive&& !isZero)||project.mode==='curricular';
      const type=isZero?'sin_lecciones':projectActive?(pedagogic?'mixta':'proyecto'):'pedagogica';
      return {
        numero:i+1, tipo_orientativo:type,
        lecciones:Number.isFinite(lessonNum)?lessonNum:null,
        fechas_declaradas:val(w.fechas??w.fecha??null),
        areas_declaradas:arr(w.areas),
        saberes_conceptuales_declarados:arr(w.saberes),
        saberes_procedimentales_declarados:arr(w.saberesProcedimentales),
        saberes_actitudinales_declarados:arr(w.saberesActitudinales),
        fases_proyecto:assigned,
        indicadores_referenciados:val(w.indicadores??null),
        decisiones_proyecto_originales:project,
        referencia_fuente:`planOriginal.semanas[${i}]`,
        pendiente_revision: (!w.saberes?.length&& !isZero)|| (projectActive&&!assigned.length)
      };
    });
    const moduleIds=arr(pia.projection?.modules).map(m=>typeof m==='string'?m:(m?.id??m?.name??null)).filter(Boolean);
    const sumLessons=weeks.reduce((n,w)=>n+(Number.isFinite(w.lecciones)?w.lecciones:0),0);
    const scheduled=Number(general.leccionesPlanificadas);
    if(Number.isFinite(scheduled)&&scheduled>0&&scheduled!==sumLessons)warnings.push(`Revisar suma de lecciones: encabezado ${scheduled}, semanas ${sumLessons}. No se modificó ninguna.`);
    if(!weeks.length) warnings.push('No hay semanas planificadas. No se puede generar un planeamiento completo.');
    if(!txt(general.ciclo)||!txt(general.nivel)) warnings.push('Faltan ciclo y/o nivel en los datos generales.');
    if(weeks.some(w=>w.pendiente_revision))warnings.push('Existen semanas sin saberes o sin fase identificada: revisar antes de generar el documento final.');
    return {
      schema_version:VERSION,
      fuente:'Exportación JSON guardada de PIA-PNFT (no atribuye a IA textos oficiales)',
      politica:'Fuente de verdad: planOriginal.json. En desacuerdo entre el índice y el estado original, consultar al docente; no corregir a ciegas.',
      datos_administrativos:general,
      ejes_transversales:arr(plan.ejesTransversales),
      metodologia:val(plan.metodologiaActiva),
      modulos_declarados:moduleIds,
      semanas:weeks,
      conteo:{semanas:weeks.length,lecciones_declaradas:Number.isFinite(scheduled)?scheduled:null,lecciones_en_semanas:sumLessons},
      referencias_completas:'planOriginal.json — conserva pia, indicadores, calendario y registros originales íntegros',
      advertencias:warnings,
      resultados_posteriores:{reflexiones:'Permanecen vacías salvo texto real provisto por el docente',observaciones:'No inventar'},
    };
  }
  function auditContent(route){
    const failures=[],warnings=[...route.advertencias];
    if(!route.semanas.length)failures.push('Sin semanas.');
    route.semanas.forEach((week,i)=>{if(week.numero!==i+1)failures.push('Numeración semanal inconsistente.');if(week.lecciones!==null&&(!Number.isInteger(week.lecciones)||week.lecciones<0))failures.push(`Semana ${i+1}: lecciones inválidas.`);if(week.lecciones===0&&week.tipo_orientativo!=='sin_lecciones')failures.push(`Semana ${i+1}: semana sin clases marcada como lectiva.`);});
    return {ok:failures.length===0,failures,warnings,protected:['No inventar IL, RdA, IE oficiales de Etapa I','Mantener separado IE II y III','No rellenar reflexiones posteriores','No inferir datos personales','La persona docente revisa y decide']};
  }
  root.PIACompletaBridge={VERSION,normalize,auditContent};
  if(typeof module!=='undefined'&&module.exports) module.exports=root.PIACompletaBridge;
})(typeof window!=='undefined'?window:globalThis);
