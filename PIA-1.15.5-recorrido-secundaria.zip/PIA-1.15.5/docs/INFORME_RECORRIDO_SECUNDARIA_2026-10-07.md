# PIA 1.15.5 — corrección del recorrido de secundaria

Entrega del 7 de octubre de 2026. Se conserva la presentación principal aprobada: colores, encabezado, cuatro pestañas, referentes curriculares y contenido. Se corrige el recorrido para reducir saltos, mostrar decisiones y permitir rectificaciones. Esta revisión no incorpora cambios curriculares ni modifica el recorrido de preescolar o primaria.

## Qué se encontró y qué se corrigió

| Aspecto observado | Causa o limitación | Resultado |
| --- | --- | --- |
| Saltos al pulsar pestañas y controles | Reconstrucción del panel, restauración prematura del foco y anclaje del desplazamiento | Se restaura foco y posición después de reconstruir la vista. La consulta no lleva al calendario. |
| Progresión sin ventana | La consulta recibía un objeto donde el servicio esperaba una lista | Ventana local con los vínculos documentados antes, en el nivel consultado y después; no cambia la selección actual. |
| Ejes llevan a metodología | Compartían el mismo destino | Consultas separadas para ejes transversales y Pensamiento de Diseño. |
| Un solo saber adicional para un vínculo | Selector individual | Casillas para varios saberes adicionales; admite grupos de dos, tres o más. No combina ni reescribe indicadores oficiales. |
| Mediación con saberes ocultos | Listas plegadas y pérdida de apertura al reconstruir | Saberes procedimentales, saberes actitudinales y ejes visibles al editar mediación; se conservan selecciones y acciones. |
| Falta de rectificación | Deshacer estaba escondido; no había cancelación del detalle | Deshacer visible y Cancelar cambios de este detalle. Cancelar restaura las decisiones anteriores a su apertura. |
| Proyecto poco claro | No presentaba juntos propósito y saberes asignados | Resumen de la etapa/fase, propósito orientador y saberes vinculados, identificados como componente Proyecto. |
| Edición aparentemente limitada | La acción de edición no era evidente y el detalle podía quedar en otra vista | Editar decisiones abre el mismo detalle desde inventario, semanas o Proyecto. |
| Fases difíciles de desmarcar | Selector múltiple poco claro en celular | Casillas para marcar y desmarcar fases del calendario, incluso dejar todas sin seleccionar. |
| Copia de consulta sin confirmación | Fallo del portapapeles silenciado | Aviso de éxito real y del paso siguiente; si falla, ofrece copiar manualmente o descargar. |
| Tres propuestas sin vista previa | Se mostraban como listas dentro de la página | Cada propuesta se puede revisar en una ventana. Abrirla no cambia decisiones; aplicar requiere una acción explícita. |
| Ediciones cerraban secciones | El panel se reconstruía sin conservar la apertura | Se conserva la apertura de las secciones, la etapa/fase y el foco pertinente. |

## Recorrido recomendado para el docente

1. **Marco curricular.** Elija nivel y módulo. Revise competencias, resultados de aprendizaje y perfiles de salida. Consulte progresión cuando necesite verificar continuidad. Estas consultas no incluyen saberes automáticamente.
2. **Datos iniciales y tiempo.** Revise marco temporal, diagnóstico y perfil de evaluación. Declare las semanas sin lecciones o con disponibilidad parcial en el calendario; PIA no presupone feriados.
3. **Saberes e indicadores.** Elija Organizar directamente o Recibir ayuda de IA. Ambas opciones conducen a la misma distribución.
4. **Si utiliza IA:** pulse Preparar y copiar consulta; compruebe el aviso. Pegue la consulta en su herramienta de IA. Al regresar, pegue la respuesta JSON o impórtela; pulse Validar y mostrar propuestas. Abra las ventanas de las propuestas, compare y aplique solo la que decida usar como borrador. La validación comprueba estructura y correspondencia con la selección, no pertinencia pedagógica.
5. **Edite decisiones.** Incluya los saberes pertinentes. En cada uno, decida lecciones pedagógicas, fases del Proyecto, semanas y vínculos. Puede incluir dos o tres saberes en un vínculo, de la misma área o de distintas áreas, revisando el aporte de cada indicador.
6. **Distribución por semanas.** Revise secuencia y tiempo. Editar semana modifica disponibilidad, condición y actividad; Editar un saber modifica su asignación curricular. Son funciones diferentes sobre una misma distribución, no dos proyecciones.
7. **Proyecto y mediación.** Elija la etapa/fase. Revise qué saberes están vinculados, su aporte y secuencia. Describa acciones y movilice saberes procedimentales, saberes actitudinales, ejes transversales y apoyos DUA. La Etapa I Inicial conserva sus indicadores propios del componente Proyecto.
8. **Evaluación prevista.** Para la Etapa II Desarrollo y la Etapa III Final, revise evidencias e indicadores de evaluación diferenciados según el alcance curricular. Las sugerencias de IA requieren decisión y contextualización docente. No se asignan puntos ni calificaciones automáticamente.
9. **Revise y guarde.** El organizador de la ruta curricular es una vista opcional para revisar o editar estas mismas decisiones. El prompt de proyección semestral utiliza la distribución realizada; no exige repetir el proceso en el mapa.

## Cómo corregir una decisión

- **Desmarcar:** quite la casilla de la fase que no corresponde. Puede conservar lecciones pedagógicas sin fases del Proyecto.
- **Cancelar cambios de este detalle:** revierte las decisiones realizadas desde que abrió el detalle. Los campos siguen autoguardándose mientras trabaja; Cancelar realiza la restauración.
- **Deshacer último cambio:** revierte el último cambio registrado durante la sesión. El historial no sustituye los archivos guardados ni se conserva después de recargar.
- **Volver a la distribución:** cierra el detalle conservando los cambios; no los cancela.
- **Guardar decisiones y volver:** conserva los cambios y regresa a la misma distribución.

## Qué se edita y qué se conserva

Las decisiones de ubicación, fases, semanas, vínculos, mediación, evidencia y evaluación prevista son editables. Los nombres y textos oficiales de saberes conceptuales e indicadores de logro están protegidos; no se habilita su reescritura como si fuera contenido oficial. Los vínculos conservan las semanas y fases individuales de cada saber.

La situación problema y el producto pueden quedar pendientes en la proyección. El acompañamiento de PIA no define un tema o producto único para el estudiantado ni afirma que los aprendizajes fueron alcanzados. Los recordatorios nuevos son orientación de interfaz; no sustituyen las fuentes oficiales ni crean categorías curriculares.

## Validación

- **316 pruebas automatizadas de fuente, contratos y lógica:** aprobadas.
- **86 escenarios de navegador Chromium:** aprobados, sin errores de ejecución de página.
- Incluyen ambos módulos de sétimo, octavo y noveno; navegación sin saltos en los casos reportados; consulta de progresión y ejes; vínculo de tres saberes; cancelación y deshacer; desmarcado de fases; mediación; copia exitosa y fallida; vista previa y aplicación de tres propuestas.
- Guardado JSON, carga mediante selector real, autoguardado, recuperación, prompt semestral editado, exportación Word, PDF, impresión de la proyección y versión portable autónoma.
- Comprobación de secundaria a 320, 390, 820 y 1440 píxeles, consulta de propuestas a 320 píxeles y revisión general de cuatro ciclos a cuatro anchos móviles.
- Los resultados reproducibles están en los cuatro archivos de resultados de navegador de tests/. El ensayo docente es interno: no constituye aprobación de usabilidad por docentes participantes ni prueba en dispositivos físicos.

## Alcance de la entrega

La fuente de aplicación modificada en este turno se limita a src/application/enhancements.js y src/styles/08-enhancements.css. Se incluyen pruebas y documentación actualizadas. Los HTML de raíz, web y portable se generan desde la fuente y tienen el mismo contenido. No se modifica el catálogo curricular, el perfil oficial de evaluación, los porcentajes ni los exportadores.

El ZIP conserva código, datos, recursos de la aplicación, contratos visuales y pruebas. Se excluyen únicamente capturas y exportaciones producidas por las pruebas para mantener el paquete pequeño. Los resultados JSON se incluyen.
