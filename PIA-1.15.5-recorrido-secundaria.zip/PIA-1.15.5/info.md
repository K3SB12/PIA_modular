# Estado operativo — PIA-PNFT Modular 1.15.5

## Entrega vigente — recorrido de secundaria, 2026-10-07

Se corrige navegación, consultas, vínculos, rectificación y propuestas de IA, conservando la presentación principal. Pruebas: 316 automatizadas y 86 escenarios de navegador, aprobados. Consulte docs/INFORME_RECORRIDO_SECUNDARIA_2026-10-07.md y tests/secondary-workflow-browser-results.json. Los apartados siguientes son registros históricos; la huella vigente figura al final de este archivo.

## Entrega vigente — rediseño de secundaria

Cuatro pestañas implementadas, con Marco curricular primero. 312 pruebas automatizadas y 38 escenarios en Chromium aprobados. Guardado, carga, autoguardado, Word, PDF y portable comprobados. Preescolar y primaria conservan sus controles y prompts. Consulte docs/INFORME_REDISENIO_SECUNDARIA.md; los apartados siguientes documentan entregas anteriores. SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.


Corrección vigente: consulta de RdA, competencias y perfiles desde el módulo de secundaria, sin seleccionar saberes. Referentes visuales independientes del alcance de prompts y ruta. Textos oficiales intactos. SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`. La revisión final en navegador de los cambios de interfaz previos sigue pendiente.

Entrega para revisión: pantalla duplicada del Proyecto retirada en secundaria; campos originales e indicadores de Etapa I Inicial integrados en el nuevo módulo. Se conservan perfil de evaluación y organizador opcional. Guía y áreas compactadas. Prueba final en navegador y aprobación de usabilidad pendientes. SHA-256 vigente: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.15.3 — interfaz de secundaria

- Áreas de conocimiento visibles al elegir nivel y módulo, sin selección curricular automática.
- Guía inicial abierta, seis pasos reversibles y edición contextual por decisión.
- Panel lateral en escritorio y diálogo en celular/tablet, con regreso explícito y campos conservados.
- Distribución por semanas con calendario, recesos y disponibilidad parcial editables.
- Conserva el currículo literal, la evaluación prevista, el prompt exclusivo de secundaria y la persistencia de 1.15.2.

**Estado de validación:** pruebas Node y controles de fuente, build, alcance e integridad; consultar resultados en el informe. Se aprobaron 16 escenarios de navegador en la revisión previa a los últimos ajustes menores. La repetición final del escenario guiado de tres tamaños está pendiente por indisponibilidad del navegador. No se certifica aprobación de usabilidad por docentes ni prueba en dispositivos físicos. Huella SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Corrección 1.15.1

- Se restablecen los botones **Continuar un planeamiento** de la portada y **Abrir** de la barra principal.
- Se elimina la apertura diferida del selector JSON que podía ser bloqueada por el navegador.
- Cancelar conserva la portada; la transición a la plantilla ocurre después de cargar el plan.
- La compatibilidad con JSON anteriores, la migración y el resto de funciones de PIA permanecen intactos.

**Validación final:** 273/273 pruebas aprobadas; 115 botones inventariados; alcance autorizado e integridad aprobados. Huella SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.15.0

- Flujo de III Ciclo reordenado y simplificado a partir de las pruebas con personas asesoras.
- Confirmación explícita del perfil antes de habilitar Proyecto y comprobación de prerrequisitos al abrir la ruta.
- Tres acciones principales para consultar una IA externa, con propuestas humanizadas, contrato v4, producto, recursos, evidencia e historial de revisiones.
- Orientación local sin API, basada en fuentes incorporadas, con páginas, confianza, preguntas relacionadas y salida prudente.
- Actividades puntuales semanales persistentes, diferenciadas de las metodologías y coherentes con la modalidad de la semana.
- DUA, apoyos autorizados, referencias opcionales y privacidad reforzados en prompts y controles.
- Responsividad ampliada para el mapa, calendario, propuestas y diálogo de orientación.

**Validación final:** 268/268 pruebas aprobadas; alcance autorizado e integridad aprobados. Huella SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.


## Actualización 1.14.4

- Ajuste controlado de exportación Word: página Carta horizontal, ancho institucional estable de 701.7 pt, proporciones de columnas alineadas con la plantilla oficial 2026 y eliminación de expansión lateral de títulos/tablas. No modifica currículo, semanas, JSON, PDF ni lógica funcional.
- Revisión posterior a prueba real: vista conceptual preliminar por nodos en cada propuesta, porcentajes aclarados como Solo lecciones / Solo Proyecto / Lecciones + Proyecto / Pendiente y presencia total del Proyecto.
- Descarga local de la respuesta de IA en `.md` y de las propuestas validadas en `.json`.
- Doble clic mapa→tabla corregido sin reconstrucción del nodo en el primer clic.
- Persistencia local de la distribución visual del grafo al guardar y volver a abrir, sin convertir las coordenadas en decisiones curriculares ni enviarlas a los prompts.
- Oportunidades orientadoras de Trabajo cotidiano/Tarea en la comparación; instrumentos reservados para la mediación semanal.

- Circuito de IA estructurado con Markdown o `.json`, validación previa y aplicación explícita por la persona docente.
- Exportación de consulta Markdown, ruta JSON y mapa PNG.
- Continuación visible hacia proyección semestral o estrategias semana a semana desde la ruta guardada.
- Persistencia de respuesta, propuesta, opción elegida, fases y prompt semanal.
- Cinco fases de Pensamiento de Diseño protegidas cuando el Proyecto está activo.
- Barra inferior corregida: sin margen negativo ni superposición sobre la auditoría; acciones adaptables a móvil.
- Navegación mapa→tabla por doble clic y retorno al mapa.
- Tema claro/oscuro persistente y selección inicial correcta I→1.º, II→4.º, III→7.º.
- Contrato `pia-route-options-v4` para comparar o revisar la propuesta elegida con identificador, copia de referencia e historial; importación por pegado o archivo `.json`, `.md` o `.txt`.
- Descarga independiente de la propuesta elegida en `.json` para conservarla o solicitarle ajustes a la IA sin perder su identidad.
- Exportación Word/PDF del semestre completo, un rango o semanas específicas, manteniendo la numeración y el contenido semanal trazable.
- Reflexión docente propia por semana con la estructura oficial conservada: qué funcionó, qué no funcionó, qué puedo mejorar y observaciones/recomendaciones por nivel. Se retira la repetición general final de la interfaz y de las exportaciones, sin descartar datos históricos al cargar planes anteriores.
- Se restaura íntegramente **PIA Journey · La Ruta del Docente**, incluido el mapa de progresión curricular o “ruta del tesoro”.
- Contraste oscuro ampliado en formularios, ayudas, trayectoria curricular, RdA, tarjetas, estados, campos desactivados, textos provisionales y foco de teclado; se eliminan distintivos técnicos impropios de la interfaz docente.
- Portada aprobada: conjunto PNFT transparente, sin año ni pie repetido, con los tres botones originales próximos al gráfico. Contextualización/DUA e Indicadores de referencia completan su cobertura de superficies y textos en modo oscuro.

**Validación final:** 253/253 pruebas automatizadas previstas para esta entrega; las tres salidas HTML son idénticas. Huella SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.9.2

- El calendario visual se encuentra dentro del constructor de la ruta curricular de III Ciclo, debajo del mapa.
- Presenta una línea temporal semanal con diagnóstico, mediación curricular, fases APD del Proyecto, trabajo cotidiano y tareas confirmadas.
- Las semanas y fases proceden de las decisiones registradas en el mapa; la duración estimada del Proyecto no se usa para inventar su posición.
- Las ventanas evaluativas requieren perfil confirmado y vigencia; las decisiones obsoletas o pendientes no se colocan.
- Una tabla accesible presenta el mismo contenido; la navegación se reorganiza para computadora, tableta y celular.
- Cada saber se ubica en lecciones pedagógicas, componente Proyecto, ambos o pendiente.
- El inspector muestra relaciones previamente revisadas y coincidencias textuales con rótulos y colores complementarios; la relación y el contexto escrito son opcionales.
- Cuando no existe antecedente curricular explícito, PIA informa que el saber inicia en el nivel actual y no inventa una base.
- PIA ofrece productos físicos, simulados, programados, multimedia, documentales y alternativas de baja tecnología sin imponer un tema ni un formato; el verbo del indicador se conserva.
- La vista no escribe las semanas del planeamiento, no se incorpora al Word o PDF oficial y no certifica viabilidad ni logro.

Validación automatizada: **210/210 pruebas aprobadas**. Huella SHA-256 de las tres salidas HTML: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.9.1

La ruta de III Ciclo se presenta ahora como un mapa conceptual real: raíz semestral, ramas de diagnóstico, Proyecto con las cinco fases de Pensamiento de Diseño, mediación curricular, evaluación y norte curricular, con conexiones curvas y nodos seleccionables. Un control de entrada verifica que currículo, tiempo, contexto, diagnóstico, DUA, recursos, evaluación y decisiones docentes lleguen al mapa y al prompt sin inventar campos opcionales.

Huella SHA-256 de las tres salidas HTML: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.9.0

- Mapa integral local para III Ciclo con una sola ruta de mediación curricular y Proyecto.
- Fases APD, indicadores protegidos, semanas, relaciones, grupos, evidencias y capas transversales visibles.
- Inspector y tabla accesible equivalentes; modo guiado y directo; funcionamiento con teclado, toque y ratón.
- Auditoría estructural, curricular, temporal y de duplicación de evidencias, sin certificación automática.
- Prompt local para comparar dos o tres enfoques antes de generar la proyección semestral.
- Exportación PNG e impresión/Guardar como PDF exclusiva del mapa; las salidas oficiales no cambian.
- Persistencia compatible en `schemaVersion: 6`; funcionamiento autónomo y sin red.
- Validación automatizada: 192/192 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.8.0

- Secundaria: nuevo organizador de ruta curricular separado del formulario del Proyecto.
- Rutas: Proyecto predominante, alternancia, preparación inicial o solicitud de apoyo para decidir.
- Mapa: vista conceptual local y tabla accesible equivalente; textos curriculares protegidos.
- Funciones: Proyecto directo, preparación, apoyo/documentación, otras lecciones pedagógicas, continuidad y pendiente.
- Responsabilidad: la auditoría local orienta cobertura y tiempo declarado, pero no certifica viabilidad, RdA ni aprendizaje.
- IA: el prompt recibe únicamente las decisiones registradas y conserva visibles los pendientes.
- Compatibilidad: `schemaVersion: 6`, planes anteriores, funcionamiento local y exportaciones oficiales preservados.
- Integridad: nueva verificación automática de versión, equivalencia de las tres salidas y `CURRENT.sha256`.
- Validación automatizada: 186/186 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.7.5

- Interfaz diagnóstica: selección manual de técnica e instrumento bajo control opcional; campos ocultos por defecto.
- Recomendación automática: una sola combinación técnica–instrumento, fundamentada en actividad y evidencia, sin duplicar decisiones.
- Alineación: Orientaciones Docentes PNFT 2026, recurso “Evaluación de los aprendizajes en la Malla Curricular de Formación Tecnológica”, disposiciones del Departamento de Evaluación de los Aprendizajes y REA vigente.
- Alcance: saberes conceptuales, procedimentales y actitudinales del módulo mediante experiencia integrada, sin exigir indicadores actuales como dominio previo.
- Tiempo: máximo dos lecciones; no se crean pruebas independientes para cada saber.
- Compatibilidad: planes históricos con técnica o instrumento elegidos activan automáticamente la selección manual.
- Validación automatizada: 179/179 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.7.4

- Diagnóstico: corrige la atribución indebida de “Observación” y “Lista de cotejo” cuando la persona usuaria dejó activa la solicitud de recomendación a la IA.
- Procedencia: muestra si técnica e instrumento están pendientes de recomendación o fueron seleccionados expresamente por la persona docente.
- Prompt: obliga a rotular toda recomendación de IA como pendiente de validación y prohíbe presentarla como seleccionada, confirmada o autorizada.
- Word: conserva el estado de cada decisión y aclara que anexar una respuesta revisada no equivale a confirmarla.
- Compatibilidad: mantiene `schemaVersion: 6`, currículo protegido, planes anteriores y funcionamiento local.
- Validación automatizada: 174/174 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.7.3

- Secundaria: APD se presenta como una única ruta que articula saberes, indicadores, Proyecto y evidencias; las opciones de doble metodología quedan diferenciadas como excepciones sujetas a revisión.
- Diagnóstico: se mantiene visible “Condiciones de entrada para los saberes actuales” con una explicación contextual que evita tratar los indicadores actuales como dominio previo.
- Interfaz: los cuadros de prompt se adaptan a monitores de menor altura mediante límite de viewport y desplazamiento interno.
- Terminología: las salidas visibles usan “lecciones pedagógicas” en lugar de “lecciones administrativas”.
- Compatibilidad: se conserva `schemaVersion: 6`, funcionamiento local, planes anteriores, currículo protegido y las tres salidas HTML equivalentes.
- Validación automatizada: 170/170 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.7.2

- Diagnóstico: selección asistida de técnica e instrumento, prompt que genera la experiencia, la evidencia y un instrumento completo, y Word editable con plantilla específica.
- Seguridad pedagógica: no se inventan resultados, no se asigna calificación y la sistematización se completa después de aplicar el diagnóstico.
- Secundaria: ficha de coordinación metodológica con decisión responsable, notas, confirmación de revisión y alertas para ABR, ABJ, APD u otra metodología.
- Doble metodología: el prompt exige fases completas, puentes, distribución temporal, evidencias y riesgos de duplicación; PIA no toma la decisión final.
- Tiempo: 80 minutos continúa como referencia oficial; el escenario opcional de tiempo efectivo se muestra y audita aparte como dato preventivo no oficial.
- Currículo: corregida la omisión de Operadores relacionales en 3.º, Módulo 1. No era un problema de comillas, sino un registro independiente faltante.
- Catálogo: 236 saberes–indicadores; `schemaVersion: 6` y compatibilidad histórica conservados.
- Validación automatizada: 165/165 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Revisión de asesoría sobre 1.7.1

- Marco curricular: PIA presenta competencias específicas, perfiles de salida y propósito oficial del módulo para la selección actual, con fuente y páginas de guía.
- Responsabilidad: competencias, RdA y perfil son referentes de progresión; la planificación no equivale a logro demostrado.
- Integración: el prompt solicita dos o más saberes cuando exista lógica pedagógica y exige justificar el abordaje individual cuando la profundidad lo requiera.
- DUA: opera como principio general del diseño; el registro contextual permanece opcional y solo se incorpora al prompt mediante decisión expresa.
- Recursos: inventario general de equipos, software, materiales, organización, accesibilidad y limitaciones, sin datos personales.
- Diagnóstico: nuevo modelo editable en Word, claramente rotulado como ejemplo no obligatorio y sin resultados inventados.
- Trazabilidad: nueva auditoría de contribución de la ruta con vacíos y decisiones pendientes; no certifica RdA, aprendizaje ni promoción.
- Proyecto: no impone tema único ni una cantidad universal de indicadores.
- Compatibilidad: `schemaVersion: 6`, JSON, autoguardado, portable, Word/PDF oficiales y currículo protegido conservados.
- Validación automatizada de la revisión 1.7.1: 160/160 pruebas aprobadas; esta huella fue sustituida por la entrega 1.7.2.

## Actualización 1.7.1

- Incidencia corregida: el botón **Explorar un ejemplo de planeamiento** ya no inhabilita su propio contenedor.
- Accesibilidad: se aíslan los elementos hermanos mientras la experiencia está abierta y se restauran `inert`, `aria-hidden` y foco al salir.
- Contextualización: nueva diferenciación entre DUA, acceso, apoyo no significativo y adecuación significativa o PEI previamente aprobada.
- Plan Nacional: guía para coordinación con docente guía/equipo, diagnóstico, selección y dosificación contextualizada de saberes y dos lecciones semanales.
- Protección: PIA no aprueba adecuaciones, no interpreta PEI, no almacena datos individuales y no modifica el currículo automáticamente.
- Límite: el catálogo integrado llega hasta 9.º; 10.º–12.º requieren fuente oficial vigente y no se completan por inferencia.
- Compatibilidad: `schemaVersion: 6`, planes anteriores, Ruta hacia el RdA, JSON, PDF, Word y portable preservados.
- Validación automatizada: 156/156 pruebas aprobadas, incluidas cinco nuevas regresiones específicas; las tres salidas HTML conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.

## Actualización 1.7.0

- Estado: implementación de la Ruta hacia el RdA en una copia independiente de 1.6.15.
- Alcance: consulta estructural de Preescolar a 9.º, organizada por familias, niveles, ciclos, áreas, indicadores y RdA.
- Responsabilidad: vínculo estructural y correspondencia pedagógica validada permanecen separados; no se infieren relaciones pendientes.
- Interfaz: vista local de solo lectura, con filtros por área y alcance, RdA literal, hitos por nivel, estados curriculares y procedencia.
- Protección: solo el nivel actual corresponde al planeamiento; la Ruta no escribe semanas, prompts, diagnóstico, Proyecto ni exportaciones.
- Compatibilidad: `schemaVersion: 6`, operación local, planes 1.6.15, JSON, PDF, Word y portable preservados.
- Validación automatizada: 151/151 pruebas aprobadas; las tres salidas HTML son idénticas y conservan SHA-256 `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.
- Cobertura comprobada: 38 familias, 16 RdA, 10 niveles, 20 combinaciones nivel–módulo y los 235 saberes–indicadores disponibles en PIA.
- Correspondencias pedagógicas aprobadas incorporadas: 0. Este valor es deliberado mientras no exista una matriz oficial con fuente, autoridad, fecha y versión de aprobación.
- Validación institucional pendiente: correspondencias pedagógicas indicador–RdA y prueba humana final en Chrome/Edge de escritorio y móvil.

## Actualización 1.6.15

- Estado: implementación correctiva completa; 143/143 pruebas automatizadas aprobadas.
- Currículo: catálogos protegidos sin cambios; prueba exhaustiva de 235 indicadores y 20 combinaciones.
- Evaluación: perfil de referencia pendiente hasta confirmación docente explícita; Proyecto condicionado a esa confirmación.
- Módulos: la selección conjunta exige confirmar que el marco temporal cubre ambos periodos.
- Tiempo: presupuesto neto calculado en lecciones y minutos después de las reservas declaradas.
- IA: prompt con balance temporal numérico y comprobación técnica delimitada; no se presenta como certificación pedagógica.
- Preescolar: comprobación específica de sus saberes procedimentales y actitudinales.
- Compatibilidad: `schemaVersion: 6`, planes anteriores, operación local, JSON, PDF, Word y portable preservados.
- Pendiente institucional: prueba humana final en Chrome/Edge de escritorio y móvil.

## Actualización 1.6.14

- Estado: implementación completa y pruebas automatizadas aprobadas.
- Alcance: experiencia formativa guiada desde la portada, sin cambios al currículo oficial ni al esquema JSON v6.
- Recorrido: siete momentos y tres laboratorios de metodología; ejemplos diferenciados por ciclo e integración de Proyecto en secundaria.
- Protección: el ejemplo no modifica el plan y su avance utiliza una clave local independiente.
- Persistencia: el planeamiento conserva autoguardado, JSON, portable, PDF y Word; la experiencia queda fuera de las salidas oficiales.
- Verificación de interacción: apertura, siete vistas, ABJ/ABR/APD, salida y preservación del plan verificadas en DOM ejecutable sin errores de consola.
- Limitación de validación: el navegador remoto bloqueó la URL local, por lo que la revisión visual real en Chrome o Edge debe realizarse antes de publicación. La entrega no se rotula como visualmente validada.

- Fecha de corte: 2026-09-11.
- Estado: versión correctiva construida sobre PIA 1.6.12; consolida la trayectoria curricular, el
  diagnóstico opcional, la orientación evaluativa y la auditoría temporal posterior.
- Validación automatizada: 132/132 pruebas aprobadas. La revisión visual final se ejecuta antes de la entrega.
- Fuente editable: `src/`.
- Salidas: `index.html`, `dist/web/index.html`, `dist/portable/index.html`.
- Referencia protegida SHA-256: `c9a17130ad24b4ad0b3249b288046862603b3861172e877883432e7792d8e605`.
- Datos curriculares base: `pnft-data.js` y `rda-por-ciclo.js` conservados. Preescolar se corrige mediante
  un catálogo oficial aislado y reversible para Básico requerido y Óptimo.
- Centros: 4.651 registros mínimos; 4.448 códigos de coincidencia única y 63 ambiguos. Se excluyen
  todos los `0000`; no se incluyen personas asesoras, correos ni teléfonos.
- Backend, API, autenticación y analítica activa: no implementados.
- Planes: JSON v6 con migración de versiones anteriores y conservación de texto oficial, contextualizado y prompts editados.
- Portada: entrada local MEP–PNFT–PIA con inicio, carga de JSON, preferencia de omisión por dispositivo
  y retorno sin pérdida. No se imprime ni se exporta.
- Identidad institucional: escudo y lema opcionales alineados a la izquierda; el nombre del centro no
  se duplica y el encabezado administrativo oficial permanece intacto.
- Diagnóstico: inicia con 0 lecciones y desactivado; dispone de modo asesor y docente, áreas de valoración,
  experiencia, resultados generales, decisiones, prompt editable, guardado y reinicio independiente. Solo
  se incorpora al prompt semestral mediante activación expresa.
- Acceso al diagnóstico: el selector de lecciones permanece en Marco temporal y el botón se presenta
  después de Saberes. Se habilita con ciclo, nivel, módulo, área, saber conceptual y una o dos lecciones;
  omitirlo nunca bloquea la proyección semestral.
- Ayudas contextuales: glosario interno para DUA, referencias, proyección, diagnóstico, RdA, saberes,
  Proyecto y evaluación. Funciona mediante puntero, teclado o toque, muestra una ayuda a la vez y queda
  fuera del estado persistente, los prompts y las exportaciones.
- Contextualización y DUA: conserva los tres campos abiertos e incorpora perfil de implementación,
  condiciones complementarias, escenario tecnológico y punto de partida grupal. No admite datos
  personales del estudiantado.
- Contexto en prompts: solo se incluyen campos completados o selecciones no neutrales. Los valores
  iniciales, las condiciones no marcadas y las referencias no elegidas se omiten para evitar ruido.
- Perfiles de implementación: Regular, Aula Edad, aulas integradas, Vocacional y EPJA. Son contexto
  pedagógico y no sustituyen una modalidad o un perfil de evaluación confirmado.
- Referencias curriculares: selección controlada de indicadores de otros niveles desde el catálogo del
  PNFT, con procedencia, motivo y contextualización separados. No se presentan como indicadores oficiales
  del nivel administrativo actual.
- Prompts: General, Semestral y Semanal mantienen borradores independientes y permiten guardar,
  actualizar desde PIA o restablecer la propuesta generada con protección contra sobrescritura.
- Proyección: referencia curricular local con RdA visibles; sin distribución automática ni espacio
  para pegar/aprobar respuestas de IA.
- Semanas: navegación compacta, momento pedagógico visible y formato contextual exclusivo de
  mediación/evaluación. Al sombrear texto, la barra conserva la selección e identifica el campo activo;
  las opciones secundarias permanecen plegadas para no cubrir ni saturar la escritura.
- Edición enriquecida: incorpora estilos rápidos Inicio–Desarrollo–Cierre para mediación, sangría,
  limpieza de selección, pegado limpio opcional y vínculos HTTPS revisados por la persona docente.
  Los Indicadores de logro del currículo de FT continúan protegidos.
- Currículo semanal: selector independiente de Módulo 1, Módulo 2 o ambos junto al momento pedagógico.
  Filtra las áreas y saberes disponibles, muestra los RdA aplicables y conserva selecciones externas sin borrarlas.
- Correspondencia semanal: `saberRefs` identifica módulo, área y saber; el indicador automático se
  obtiene del módulo exacto, manteniendo `saberes` para exportación y compatibilidad histórica.
- Visualización semanal: áreas, RdA y saberes conceptuales se agrupan en un panel plegable que no
  modifica ni elimina el contenido de la semana.
- Prompt semestral: requiere metodología activa, la usa como andamiaje continuo y progresivo, omite
  datos opcionales ausentes y enlaza cada área, saber, indicador de logro del PNFT y RdA.
- Progresión curricular: 38 familias, cuatro áreas y diez niveles. Los 236 saberes-indicadores de
  PIA se relacionan de forma exacta con su familia; la vista permite consultar el módulo completo o
  solo los saberes de la proyección y no altera el currículo.
- Lectura de matriz: una celda vacía significa que no existe abordaje conceptual documentado; no permite
  inferir refuerzo, enseñanza ni dominio. `N/A` significa no aplicable. Fortalecimiento o presencia sin
  indicador solo se registran con respaldo curricular expreso.
- Interpretación: el nivel seleccionado gobierna toda la proyección; los antecedentes no confirman
  enseñanza o aprendizaje y deben comprobarse mediante diagnóstico.
- Prompt docente: no recibe la trayectoria, las familias ni los alcances anteriores o posteriores. La
  ventana local presenta tarjetas y tabla, filtros por módulo, área y alcance, RdA y fuentes oficiales.
- Auditoría temporal: la IA revisa su distribución ya construida y emite una conclusión fundada; PIA no
  interpreta una diferencia entre cantidad de indicadores y bloques como sobrecarga automática.
- Evaluación: catálogo interno y ventanas orientadoras editables. “Durante todo el periodo” no impone
  frecuencia semanal; la persona docente decide cuántas observaciones realizar. El campo “Observación o
  decisión docente” no representa una calificación.
- Revisión de IA: las respuestas general, semestral y semanal pueden pegarse y conservarse localmente.
  PIA detecta coincidencias literales y alertas contractuales básicas, pero no incorpora ni aprueba la respuesta.
- Proyecto: activación condicionada, ruta completa seleccionable y modalidad semanal curricular/mixta/integrada. La etapa inicial conserva indicadores oficiales; Prototipar y Probar/Evaluar vinculan indicadores oficiales del módulo y conservan textos históricos anteriores.
- Juego metodológico: siete misiones locales, accesibles y responsivas; incluye ruta diferenciada de Preescolar, ABJ, ABR, APD, una o dos metodologías en secundaria y evaluación diagnóstica/DUA. No modifica el plan.
- Vista: Proyección semestral puede plegarse sin pérdida de información.
- Vista complementaria: Contextualización/DUA y Seguridad/recuperación son desplegables; los botones
  de autoguardado y diagnóstico conservan sus identificadores y el modal permanece independiente.
- Prompt semestral: al regenerarse, toma las fechas actuales y protege un texto previo mediante confirmación.
- IA: contratos estrictos de literalidad, integración justificada, saberes de los tres tipos por semana y actividades desarrolladas.
- Interfaz de Preescolar: itinerario visible y habilitado exclusivamente en Materno Infantil/Transición + `0°`.
- Prompt de Preescolar: incorpora competencia y perfil de salida de las áreas elegidas, conserva el
  enfoque lúdico y emite solamente evaluación diagnóstica/formativa sin distribución porcentual.
- Proyecto en prompts: ausente en Preescolar, I y II Ciclo; en III Ciclo muestra el estado no
  seleccionado o, si se activa, la ruta e indicadores correspondientes.
- Exportación oficial: PDF y Word excluyen Proyección y Cobertura e incorporan, dentro de las columnas
  existentes, los indicadores seleccionados del Proyecto usando la edición docente o el original guardado.
- Word reserva espacios blancos amplios para Reflexiones y Observaciones.
- Continuación recomendada: validación curricular asesora de las 38 familias, piloto docente,
  observación de usabilidad, prueba de los perfiles/contextos y definición institucional de requisitos
  de seguridad/privacidad antes de activar analítica o backend.


Entrega de recorrido de secundaria, 2026-10-07. SHA-256 vigente: `3a23d76f06c12f12ec1fffa4c2cd1a63c629b1b27dd53da42de609052e75f064`. Consulte docs/INFORME_RECORRIDO_SECUNDARIA_2026-10-07.md.
